<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>

</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language: English/ Grade 7/ Book: English Reading Book</h3></center>
<hr style="width:300px">
<h1>Select Chapter</h1>
<hr>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%201%20-%20What%20You%20see%20-%20ok.pdf" target="_blank">&#x1f4d5; 01 What you see</a></div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%202%20-%20Friends%20In%20Deed%20-%20ok.pdf" target="_blank">&#x1f4d5; 02 Friends Indeed</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%203%20-%20pleasure%20-%20ok.pdf" target="_blank">&#x1f4d5; 03 Pleasure</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%204%20-%20A%20busy%20day%20-%20ok.pdf" target="_blank">&#x1f4d5; 04 A busy day</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%205%20-%20once%20upon%20a%20time%20-%20ok.pdf" target="_blank">&#x1f4d5; 05 Once upon a time</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%206%20-%20Better%20be%20safe%20than%20sorry%20-%20ok.pdf" target="_blank">&#x1f4d5; 06 Better safe than sorry</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%207%20-%20Around%20the%20country%20-%20ok.pdf" target="_blank">&#x1f4d5; 07 Around the country</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%208%20-%20Wonders%20Around%20Us%20-%20ok.pdf" target="_blank">&#x1f4d5; 08 Wonders around us</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%209%20-%20our%20beautiful%20world%20-%20ok.pdf" target="_blank">&#x1f4d5; 09 Our beautiful world</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/English%20Reading%20Book%20G7/Unit%2010%20-%20Future%20-%20ok.pdf" target="_blank">&#x1f4d5; 10 future</a> </div>








          </div>

		  </div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
