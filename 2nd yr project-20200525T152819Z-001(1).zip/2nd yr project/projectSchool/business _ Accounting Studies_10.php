<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>
</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language: English/ Grade 10/ Book: Business & Accounting Studies</h3></center>
<hr style="width:300px">
<h1>Select Chapter</h1>
<hr>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2001%20-%20E.pdf" target="_blank">&#x1f4d5; 01  Background of Business </a></div>

          	<div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2002%20-%20E.pdf" target="_blank">&#x1f4d5; 02 Business Environment </a></div>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2003%20-%20E.pdf" target="_blank">&#x1f4d5; 03 Business Organizations</a></div>

			<div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2004%20-%20E.pdf" target="_blank">&#x1f4d5; 04 Introduction to Accounting </a></div>

          <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2005%20-%20E.pdf" target="_blank">&#x1f4d5; 05 Accounting Equation </a></div>

           <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2006%20E.pdf" target="_blank">&#x1f4d5; 06 Dual Impact of Transactions </a></div>

			<div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2007%20-%20E.pdf" target="_blank">&#x1f4d5; 07 Prime Entry Books </a></div>

		  <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2008%20-%20E.pdf" target="_blank">&#x1f4d5; 08 The cash book and the petty cash book </a></div>

		  <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2009%20-%20E.pdf" target="_blank">&#x1f4d5; 09 Bank Account and the bank reconciliation statement </a></div>

		  <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2010%20-%20E.pdf" target="_blank">&#x1f4d5; 10 Purchase Journal, Sales Journal and General Journal </a></div>

		  <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2011%20-%20E.pdf" target="_blank">&#x1f4d5; 11 Trial Balance </a></div>

		 <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/Business%20&%20Accounting%20Studies%20-%20G%2010%20-E/Chapter%2012%20-%20E.pdf" target="_blank">&#x1f4d5; 12 Correction of accounting errors</a></div>

		 </div>

		  </div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
