<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
	<li><a href="GradeSix.php">Grade 6</a></li>
	<li><a href="GradeSeven.php">Grade 7</a></li>
	<li><a href="GradeEight.php">Grade 8</a></li>
	<li><a href="GradeNine.php">Grade 9</a></li>
	<li><a href="GradeTen.php">Grade 10</a></li>
	<li><a href="GradeEleven.php">Grade 11</a></li>
</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<img src="image/14.jpg">
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language:English/Grade 8</h3></center>
<hr style="width:300px">
<h1>Select Syllabuses</h1>
<hr>

            <div id="SelectBookList"> <a href="English Pupils Book_8.php" class="SelectSyllabuss" bookName="English Pupils Book" bookId="621" style="  ">&#x1f4d6;  English Pupils Book</a> </div>




            <div id="SelectBookList"> <a href="english Work Book_8.php" class="SelectSyllabuss" bookName="English Work Book" bookId="623" style="  ">&#x1f4d6;  English Work Book</a> </div>




            <div id="SelectBookList"> <a href="mathematics Part I_8.php" class="SelectSyllabuss" bookName="Mathematics Part I" bookId="655" style="  ">&#x1f4d6;  Mathematics Part  I </a> </div>




            <div id="SelectBookList"> <a href="mathematics Part II_8.php" class="SelectSyllabuss" bookName="Mathematics Part  II" bookId="700" style="  ">&#x1f4d6;  Mathematics Part  II</a> </div>




            <div id="SelectBookList"> <a href="science Part I_8.php" class="SelectSyllabuss" bookName="Science Part I " bookId="721" style="  ">&#x1f4d6;  Science Part I </a> </div>




            <div id="SelectBookList"> <a href="science Part II_8.php" class="SelectSyllabuss" bookName="Science Part II " bookId="625" style="  ">&#x1f4d6;  Science Part II</a> </div>




            <div id="SelectBookList"> <a href="Geography_8.php" class="SelectSyllabuss" bookName="Geography" bookId="680" style="  ">&#x1f4d6;  Geography</a> </div>




            <div id="SelectBookList"> <a href="Civic Education_8.php" class="SelectSyllabuss" bookName="Civic Education " bookId="654" style="  ">&#x1f4d6;  Civic Education </a> </div>




            <div id="SelectBookList"> <a href="Health & Physical Education_8.php" class="SelectSyllabuss" bookName="Health & Physical Education" bookId="1002" style="  ">&#x1f4d6;  Health & Physical Education</a> </div>



          </div>



 </div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
