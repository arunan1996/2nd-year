<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>

</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language: English/ Grade 7/ Book: Science Part I</h3></center>
<hr style="width:300px">
<h1>Select Chapter</h1>
<hr>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2001%20page.pdf" target="_blank">&#x1f4d5; 01 Plant Diversity</a></div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2002.pdf" target="_blank">&#x1f4d5; 02 Static Electricity</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2003.pdf" target="_blank">&#x1f4d5; 03 Generation of Electricity</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2004.pdf" target="_blank">&#x1f4d5; 04 Functions of Water</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2005.pdf" target="_blank">&#x1f4d5; 05 Acids and Bases</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2006.pdf" target="_blank">&#x1f4d5; 06 Animal Diversity</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2007.pdf" target="_blank">&#x1f4d5; 07 Forms of Energy and Uses</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%208.pdf" target="_blank">&#x1f4d5; 08 The Nature of the Earth</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%209.pdf" target="_blank">&#x1f4d5; 09 Light</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Science%20%20P1%20G%207%20(E)/Chapter%2010.pdf" target="_blank">&#x1f4d5; 10 The Correct Use of the Microscoped Uses</a> </div>












          </div>

		  </div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
