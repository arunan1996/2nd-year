

<div class="empty">
</div>
<div class="footer">
<div class="container">
  <div class="row">
    <div class="col-6">
<p class="address">Badulupitiya Road,Badulla,Sri Lanka.<br/>
<i class="fa fa-phone"></i>&nbsp;+0552223473<br/>
<a href="https://www.facebook.com/badullatamilgirlsmahavidyalam/"><i class="fab fa-facebook-f" style="font-size:20px;  margin-top:10px;">&nbsp;facebook</i></a></p>
</div>
<div class="col-6">
<p class="copyright" style="margin-right:20px">&copy;<?php echo date("Y");?>&nbsp;Copyright Badulla Tamil Girls' Maha Vidyalayam<br/>Privacy Policy</p></div>
</div>
</div>

</div>
