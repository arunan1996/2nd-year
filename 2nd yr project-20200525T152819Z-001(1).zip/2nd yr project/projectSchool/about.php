<html>
<body>





<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/AboutUs.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>

</ul>
</li>

</ul>
</div>
<img src="image/about.jpg">
<hr>
<div class="panel panel-default">
<div class="panel-body">
<h3>Our School History</h3>

<p>Nearly in 1933, Mother Maude established the school as a Catholic mixed school, as boys studied up to Grade 5, and there were all 3 mediums. After, Mother Maude, Sister Anne took charge of the school. Her school administration was very much appreciated and during her period, the school became a secondary school.
 In 1963, the school was taken over by the government and named as Tamil Girls High School, which later became Tamil Girls Maha Vidyalaya.
The first principal was Mrs.P.Gnamuttu. Following her, (1981 to 1982) Mrs.Kodeeswaran performed her duties as principal. In 1983 Mrs.W.Ganesan took over the administration. The school was functioning extremely well  and advanced levels (Arts & commerce) classes commenced during her period. Thus the school came under 1C category.
Thereafter Mrs.Selvaratnam took charge of the school in the year 1999 and up to 2013 had been serving as principal. That time the school became one of 1AB schools.
Now Mrs. Bavani is serving as principal of Badulla Tamil Girls Maha Vidyalaya. </p>
</div>
</div>
 <?php include('Footer.php'); ?>
</body>
</html>
