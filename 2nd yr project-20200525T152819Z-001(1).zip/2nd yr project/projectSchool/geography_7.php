<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>
</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language: English/ Grade 7/ Book: Geography</h3></center>
<hr style="width:300px">
<h1>Select Chapter</h1>
<hr>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/7/Geography%20G%207(%20E)/c1.pdf" target="_blank">&#x1f4d5; 01 The Planet Earth We live</a></div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Geography%20G%207(%20E)/c2.pdf" target="_blank">&#x1f4d5; 02 Identity of Sri Lanka</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Geography%20G%207(%20E)/c3.pdf" target="_blank">&#x1f4d5; 03 The landscape of Sri Lanka</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Geography%20G%207(%20E)/c4.pdf" target="_blank">&#x1f4d5; 04 Natural Hazards and Disasters</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/7/Geography%20G%207(%20E)/c5.pdf" target="_blank">&#x1f4d5; 05 Using Maps</a> </div>












          </div>

		  </div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
