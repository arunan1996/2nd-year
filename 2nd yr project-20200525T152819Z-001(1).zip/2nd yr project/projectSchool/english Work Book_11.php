<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>
</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language: English/ Grade 11/ Book: English Work Book</h3></center>
<hr style="width:300px">
<h1>Select Chapter</h1>
<hr>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/our%20responsibilities.pdf" target="_blank">&#x1f4d5; 01 Our Responsibilities </a></div>

          	<div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/facing%20.pdf" target="_blank">&#x1f4d5; 02 Facing Challengers </a></div>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/great%20lanka.pdf" target="_blank">&#x1f4d5; 03 Great Lanka </a></div>

             <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/better%20tomorrow.pdf" target="_blank">&#x1f4d5; 04 For a Better Tomorrow </a></div>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/revision%2001.pdf" target="_blank">&#x1f4d5; Revision I </a></div>

           <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/best%20time.pdf" target="_blank">&#x1f4d5; 05 Best Use of time </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/moment.pdf" target="_blank">&#x1f4d5; 06 A moment of Fun</a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/simple%20living.pdf" target="_blank">&#x1f4d5; 07 A simple Living</a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/reading%20is%20fun.pdf" target="_blank">&#x1f4d5; 08 Reading is Fun </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/enigma%20WB.pdf" target="_blank">&#x1f4d5; Revision II </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/enigma%20WB.pdf" target="_blank">&#x1f4d5; 09 Enigma </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/CHOICES%20.pdf" target="_blank">&#x1f4d5; 10 Choices in Life </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/11/English%20Work%20Book-Gr-11/revision%2003.pdf" target="_blank">&#x1f4d5; Revision III </a></div>



		 </div>

		  </div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
