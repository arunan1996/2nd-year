<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>

</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language: English/ Grade 6/ Book:  Health and Physical Education </h3></center>
<hr style="width:300px">
<h1>Select Chapter</h1>
<hr>
<div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%201.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;01 Let us lead a happy and healthy life</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%202.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;02 Let us identify needs and desires</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%203.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;03 Let us improve personality through posture</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%204.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;04 Let us enjoy our leisure through recreational games</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%205.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;05 Let us develop basic athletic skills</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%206.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;06 Let us respect rules, regulations 6 and ethics in sports</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%207.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;07 Let us get used to correct food habits to lead a healthy life</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%208.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;08 Let us maintain a healthy body</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%209.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;09 Let us improve fitness for a balanced life</a> </div>



            <div id="SelectBookList"> <a href="http://www.edupub.gov.lk/Administrator/English/6/Health%20&%20physical%20Education%20G%206%20-%20E/chap%20-%2010.pdf" class="SelectChapter" style="  " target="_blank">&#x1f4d5;10 Let us be aware and face 10 challenges</a> </div>








	</div>
	</div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
