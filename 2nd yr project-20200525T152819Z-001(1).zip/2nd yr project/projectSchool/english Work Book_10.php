<!DOCTYPE html>
<html>







<head>
<link rel="stylesheet" type="text/css" href="css/nav.css">
<link rel="stylesheet" type="text/css" href="css/Syllabus.css">
</head>
<body>
	<?php include('Header.php'); ?>

<div class="page">
<div class="nav">
<ul>
<li class="home" style="margin-left:50px;"><a href="index.php">Home</a></li>
<li class="about" style="margin-left:50px;"><a href="About.php">About</a></li>

<li class="Login" style="margin-left:50px;"><a href="login.php">Login</a></li>

<li class="syllabus"style="margin-left:50px;"><a href="#">Syllabus</a>
<ul>
<li><a href="GradeSix.php">Grade 6</a></li>
<li><a href="GradeSeven.php">Grade 7</a></li>
<li><a href="GradeEight.php">Grade 8</a></li>
<li><a href="GradeNine.php">Grade 9</a></li>
<li><a href="GradeTen.php">Grade 10</a></li>
<li><a href="GradeEleven.php">Grade 11</a></li>
</ul>
</li>

</ul>
</div>
<div class="body">
<center><h3>Syllabuses Download</h3></center>
<hr>
<div class="container">
<div class="panel panel-default">
<div class="panel-body">
<center><h3>Language: English/ Grade 10/ Book: English Work Book</h3></center>
<hr style="width:300px">
<h1>Select Chapter</h1>
<hr>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/Unit%2001%20people.pdf" target="_blank">&#x1f4d5; 01 People </a></div>

          	<div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/Unit%2002%20pdf%20on%20your%20way.pdf" target="_blank">&#x1f4d5; 02 On Your Way </a></div>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34.pdf%20Travel.pdf" target="_blank">&#x1f4d5; 03 Travel </a></div>

             <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/Unit%2004%20pdf%20Lets%20talk.pdf" target="_blank">&#x1f4d5; 04 Let s Talk </a></div>

            <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34%20best%20practices.pdf" target="_blank">&#x1f4d5; 05 Best Practices </a></div>

           <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34.pdf%20information.pdf" target="_blank">&#x1f4d5; 06 Information </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34%20learning%20is%20fun.pdf" target="_blank">&#x1f4d5; 07 Learning is Fun</a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34%20Healthy%20food.pdf" target="_blank">&#x1f4d5; 08 Healthy Food </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/Unit%2009%20nature.pdf" target="_blank">&#x1f4d5; 09 Nature </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34%20personality.pdf" target="_blank">&#x1f4d5; 10 Personality </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34%20The%20right%20career.pdf" target="_blank">&#x1f4d5; 11 The Right Career </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34%20success.pdf" target="_blank">&#x1f4d5; 12 Success </a></div>

		   <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34.pdf%20future.pdf" target="_blank">&#x1f4d5; 13 Future </a></div>

         <div id="SelectBookList"><a href="http://www.edupub.gov.lk/Administrator/English/10/English%20Work%20Book%20G%2010%20E/34.pdf%20sports.pdf" target="_blank">&#x1f4d5; 14 Sports </a></div>

		 </div>

		  </div>


 </div>

 </div>



















</div>
<?php include('Footer.php'); ?>
</body>
</html>
