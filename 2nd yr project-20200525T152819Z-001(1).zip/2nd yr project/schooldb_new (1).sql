-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Feb 20, 2019 at 06:22 PM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `schooldb_new`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `admin_id` char(4) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone_no` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`,`admin_id`),
  UNIQUE KEY `admin_id` (`admin_id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `id`, `admin_id`, `first_name`, `last_name`, `gender`, `date_of_birth`, `no`, `street`, `city`, `email`, `phone_no`) VALUES
(9051, 1, '0046', 'Banumathi', 'Puvanachandran', 'Female', '1978-08-09', 20, 'Badullupitiya Road', 'Badulla', 'banu02@gmail.com', '0786798546'),
(9052, 2, '0075', 'Uthayarani', 'Thiruchelvam', 'Female', '1975-11-30', 23, 'Lower Street', 'Badulla', 'uthya03@gmail.com', '0756798321');

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

DROP TABLE IF EXISTS `class`;
CREATE TABLE IF NOT EXISTS `class` (
  `class_id` char(3) NOT NULL,
  `grade` int(11) DEFAULT NULL,
  PRIMARY KEY (`class_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`class_id`, `grade`) VALUES
('C2', 7),
('C1', 6),
('C3', 8),
('C4', 9),
('C5', 10),
('C6', 11);

-- --------------------------------------------------------

--
-- Table structure for table `class_details`
--

DROP TABLE IF EXISTS `class_details`;
CREATE TABLE IF NOT EXISTS `class_details` (
  `class_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` char(4) DEFAULT NULL,
  `division_id` char(4) DEFAULT NULL,
  `subject_code` char(3) NOT NULL,
  `teacher_id` char(4) DEFAULT NULL,
  PRIMARY KEY (`class_detail_id`),
  KEY `class_id` (`class_id`),
  KEY `division_id` (`division_id`),
  KEY `teacher_id` (`teacher_id`),
  KEY `subject_code` (`subject_code`)
) ENGINE=MyISAM AUTO_INCREMENT=188 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `class_details`
--

INSERT INTO `class_details` (`class_detail_id`, `class_id`, `division_id`, `subject_code`, `teacher_id`) VALUES
(6, 'C4', 'D3', 'S01', '0024'),
(5, 'C4', 'D2', 'S01', '0024'),
(4, 'C4', 'D1', 'S01', '0024'),
(7, 'C4', 'D4', 'S01', '0024'),
(8, 'C4', 'D1', 'S02', '0039'),
(9, 'C4', 'D2', 'S02', '0039'),
(10, 'C4', 'D3', 'S02', '0039'),
(11, 'C4', 'D4', 'S02', '0039'),
(12, 'C4', 'D1', 'S03', '0062'),
(13, 'C4', 'D2', 'S03', '0062'),
(14, 'C4', 'D3', 'S03', '0062'),
(15, 'C4', 'D4', 'S03', '0062'),
(16, 'C4', 'D1', 'S05', '0070'),
(17, 'C4', 'D2', 'S05', '0070'),
(18, 'C4', 'D3', 'S05', '0070'),
(19, 'C4', 'D4', 'S05', '0070'),
(20, 'C4', 'D1', 'S04', '0030'),
(21, 'C4', 'D2', 'S04', '0030'),
(22, 'C4', 'D3', 'S04', '0030'),
(23, 'C4', 'D1', 'S06', '0059'),
(24, 'C4', 'D2', 'S06', '0059'),
(25, 'C4', 'D3', 'S06', '0059'),
(26, 'C4', 'D4', 'S06', '0059'),
(27, 'C4', 'D1', 'S07', '0019'),
(28, 'C4', 'D2', 'S07', '0019'),
(29, 'C4', 'D3', 'S07', '0019'),
(30, 'C4', 'D4', 'S07', '0019'),
(31, 'C4', 'D1', 'S08', '0063'),
(32, 'C4', 'D2', 'S08', '0063'),
(33, 'C4', 'D3', 'S08', '0063'),
(34, 'C4', 'D4', 'S08', '0063'),
(35, 'C4', 'D1', 'S09', '0016'),
(36, 'C4', 'D2', 'S09', '0016'),
(37, 'C4', 'D3', 'S09', '0016'),
(38, 'C4', 'D4', 'S09', '0016'),
(39, 'C4', 'D1', 'S10', '0025'),
(40, 'C4', 'D2', 'S10', '0025'),
(41, 'C4', 'D3', 'S10', '0025'),
(42, 'C4', 'D4', 'S10', '0025'),
(43, 'C4', 'D1', 'S11', '0052'),
(44, 'C4', 'D2', 'S11', '0052'),
(45, 'C4', 'D3', 'S11', '0052'),
(46, 'C4', 'D4', 'S11', '0052'),
(47, 'C4', 'D1', 'S12', '0035'),
(48, 'C4', 'D2', 'S12', '0035'),
(49, 'C4', 'D3', 'S12', '0035'),
(50, 'C4', 'D4', 'S12', '0035'),
(51, 'C4', 'D1', 'S13', '0065'),
(52, 'C4', 'D2', 'S13', '0065'),
(53, 'C4', 'D3', 'S13', '0065'),
(54, 'C4', 'D4', 'S13', '0065'),
(55, 'C4', 'D1', 'S14', '0027'),
(56, 'C4', 'D2', 'S14', '0027'),
(57, 'C4', 'D3', 'S14', '0027'),
(58, 'C4', 'D4', 'S14', '0027'),
(59, 'C4', 'D1', 'S15', '0056'),
(60, 'C4', 'D2', 'S15', '0056'),
(61, 'C4', 'D3', 'S15', '0056'),
(62, 'C4', 'D4', 'S15', '0056'),
(63, 'C4', 'D1', 'S19', '0041'),
(64, 'C4', 'D2', 'S19', '0041'),
(65, 'C4', 'D3', 'S19', '0041'),
(66, 'C4', 'D4', 'S19', '0041'),
(67, 'C4', 'D1', 'S16', '0068'),
(68, 'C4', 'D2', 'S16', '0068'),
(69, 'C4', 'D3', 'S16', '0068'),
(70, 'C4', 'D4', 'S16', '0068'),
(71, 'C4', 'D1', 'S17', '0054'),
(72, 'C4', 'D2', 'S17', '0054'),
(73, 'C4', 'D3', 'S17', '0054'),
(74, 'C4', 'D4', 'S17', '0054'),
(75, 'C4', 'D1', 'S18', '0049'),
(76, 'C4', 'D2', 'S18', '0049'),
(77, 'C4', 'D3', 'S19', '0049'),
(78, 'C4', 'D4', 'S19', '0049'),
(79, 'C4', 'D1', 'S20', '0028'),
(80, 'C4', 'D2', 'S20', '0028'),
(81, 'C4', 'D3', 'S20', '0028'),
(82, 'C4', 'D4', 'S20', '0028'),
(83, 'C4', 'D1', 'S21', '0004'),
(84, 'C4', 'D2', 'S21', '0004'),
(85, 'C4', 'D3', 'S21', '0004'),
(86, 'C4', 'D4', 'S21', '0004'),
(87, 'C4', 'D1', 'S22', '0036'),
(88, 'C4', 'D2', 'S22', '0036'),
(89, 'C4', 'D3', 'S22', '0036'),
(90, 'C4', 'D4', 'S22', '0036'),
(91, 'C4', 'D1', 'S23', '0014'),
(92, 'C4', 'D2', 'S23', '0014'),
(93, 'C4', 'D3', 'S23', '0014'),
(94, 'C4', 'D4', 'S23', '0014'),
(95, 'C5', 'D1', 'S01', '0032'),
(96, 'C5', 'D2', 'S01', '0032'),
(97, 'C5', 'D3', 'S01', '0032'),
(98, 'C5', 'D4', 'S01', '0032'),
(99, 'C5', 'D1', 'S02', '0018'),
(100, 'C5', 'D2', 'S02', '0018'),
(101, 'C5', 'D3', 'S02', '0018'),
(102, 'C5', 'D4', 'S02', '0018'),
(103, 'C5', 'D1', 'S03', '0037'),
(104, 'C5', 'D2', 'S03', '0037'),
(105, 'C5', 'D3', 'S03', '0037'),
(106, 'C5', 'D4', 'S03', '0037'),
(107, 'C5', 'D1', 'S04', '0030'),
(108, 'C5', 'D2', 'S04', '0030'),
(109, 'C5', 'D3', 'S04', '0030'),
(110, 'C5', 'D4', 'S04', '0030'),
(111, 'C5', 'D1', 'S05', '0070'),
(112, 'C5', 'D2', 'S05', '0070'),
(113, 'C5', 'D3', 'S05', '0070'),
(114, 'C5', 'D4', 'S05', '0070'),
(115, 'C5', 'D1', 'S06', '0059'),
(116, 'C5', 'D2', 'S06', '0059'),
(117, 'C5', 'D3', 'S06', '0059'),
(118, 'C5', 'D4', 'S06', '0059'),
(119, 'C5', 'D1', 'S07', '0019'),
(120, 'C5', 'D2', 'S07', '0019'),
(121, 'C5', 'D3', 'S07', '0019'),
(122, 'C5', 'D4', 'S07', '0019'),
(123, 'C5', 'D1', 'S08', '0063'),
(124, 'C5', 'D2', 'S08', '0063'),
(125, 'C5', 'D3', 'S08', '0063'),
(126, 'C5', 'D4', 'S08', '0063'),
(127, 'C5', 'D1', 'S09', '0016'),
(128, 'C5', 'D2', 'S09', '0016'),
(129, 'C5', 'D3', 'S09', '0016'),
(130, 'C5', 'D4', 'S09', '0016'),
(131, 'C5', 'D1', 'S10', '0025'),
(132, 'C5', 'D2', 'S10', '0025'),
(133, 'C5', 'D3', 'S10', '0025'),
(134, 'C5', 'D4', 'S10', '0025'),
(135, 'C5', 'D1', 'S11', '0052'),
(136, 'C5', 'D2', 'S11', '0052'),
(137, 'C5', 'D3', 'S11', '0052'),
(138, 'C5', 'D4', 'S11', '0052'),
(139, 'C5', 'D1', 'S12', '0035'),
(140, 'C5', 'D2', 'S12', '0035'),
(141, 'C5', 'D3', 'S12', '0035'),
(142, 'C5', 'D4', 'S12', '0035'),
(143, 'C5', 'D1', 'S13', '0065'),
(144, 'C5', 'D2', 'S13', '0065'),
(145, 'C5', 'D3', 'S13', '0065'),
(146, 'C5', 'D4', 'S13', '0065'),
(147, 'C5', 'D1', 'S14', '0027'),
(148, 'C5', 'D2', 'S14', '0027'),
(149, 'C5', 'D3', 'S14', '0027'),
(150, 'C5', 'D4', 'S14', '0027'),
(151, 'C5', 'D1', 'S15', '0056'),
(152, 'C5', 'D2', 'S15', '0056'),
(153, 'C5', 'D3', 'S15', '0056'),
(154, 'C5', 'D4', 'S15', '0056'),
(155, 'C5', 'D1', 'S16', '0068'),
(156, 'C5', 'D2', 'S16', '0068'),
(157, 'C5', 'D3', 'S16', '0068'),
(158, 'C5', 'D4', 'S16', '0068'),
(159, 'C5', 'D1', 'S17', '0054'),
(160, 'C5', 'D2', 'S17', '0054'),
(161, 'C5', 'D3', 'S17', '0054'),
(162, 'C5', 'D4', 'S17', '0054'),
(163, 'C5', 'D1', 'S18', '0049'),
(164, 'C5', 'D2', 'S18', '0049'),
(165, 'C5', 'D3', 'S18', '0049'),
(166, 'C5', 'D4', 'S18', '0049'),
(167, 'C5', 'D1', 'S19', '0041'),
(168, 'C5', 'D2', 'S19', '0041'),
(169, 'C5', 'D3', 'S19', '0041'),
(170, 'C5', 'D4', 'S19', '0041'),
(171, 'C5', 'D1', 'S20', '0028'),
(172, 'C5', 'D2', 'S20', '0028'),
(173, 'C5', 'D3', 'S20', '0028'),
(174, 'C5', 'D4', 'S20', '0028'),
(175, 'C5', 'D1', 'S21', '0004'),
(176, 'C5', 'D2', 'S21', '0004'),
(177, 'C5', 'D3', 'S21', '0004'),
(178, 'C5', 'D4', 'S21', '0004'),
(179, 'C5', 'D1', 'S22', '0036'),
(180, 'C5', 'D2', 'S22', '0036'),
(181, 'C5', 'D3', 'S22', '0036'),
(182, 'C5', 'D4', 'S22', '0036'),
(183, 'C5', 'D1', 'S23', '0014'),
(184, 'C5', 'D2', 'S23', '0014'),
(185, 'C5', 'D3', 'S23', '0014'),
(186, 'C5', 'D4', 'S23', '0014'),
(187, 'C5', 'D1', 'S01', '0024');

-- --------------------------------------------------------

--
-- Table structure for table `complaint`
--

DROP TABLE IF EXISTS `complaint`;
CREATE TABLE IF NOT EXISTS `complaint` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` char(4) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `recipient` varchar(50) DEFAULT NULL,
  `title` varchar(100) DEFAULT NULL,
  `subject` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`complaint_id`),
  KEY `student_id` (`student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `complaint`
--

INSERT INTO `complaint` (`complaint_id`, `student_id`, `first_name`, `last_name`, `recipient`, `title`, `subject`) VALUES
(11, 'S012', 'Kopiga', 'Baskaran', 'Admin', 'hello', 'ijdasjfioasjfiajflk fjkashfca kjaajfasjflkas '),
(3, 'S002', 'Kopiga', '', 'Admin', 'Change Address', 'new ADDRESS:\r\n4 ,\r\nkOVIL ROAD,\r\nBadulla\r\n'),
(8, 'S003', 'Raja', '', 'T002', 'Change Address', 'a;dm;asd;f'),
(5, 'S012', 'Raja', '', 'T001', 'Change Address', 'djsaldjlksl\r\ncxl;K:LCksKLCMlmklxlcmlzxkm lsJVjzkl cmmxn vkjSDZClk .mc \r\nmvklzkvc vkjcmnvxvkjZXnc kmnkjnvzckx lkz\r\njjvofjkijkzxzjzxjkhv;\r\njklxkl czckzncklzxnovhozilknxviosdjiojvlkn lknvhdvjlkzxmlkzz;lckozafpJVznkjhsdhvkz  foidjjozvD soivklzv\r\njsdvjoiguoisvjlkm\'fgjdspjvolck\r\nsjgoijgoidjvlksoijoiz\'jgvodsjk\'lsz\'oigj'),
(9, 'S003', 'Raja', '', 'T002', 'Change Address', 'hjjhbjk.j'),
(10, 'S012', 'Kopiga', '', 'T001', 'Change Address', ';,;,;l\'l\r\n;\r\nlhftygihoj,'),
(12, 'S003', 'Kopiga', 'Baskaran', 'T001', 'hello', 'jiajfajfajklf kjsdnkjsafkj JDLkjdlK'),
(13, 'S009', 'sampavi', 'shanthakumar', 'Admin', 'zdfhngjnhmj', 'xvdbgnhmjmj,kj,k'),
(14, '1064', 'Ramanathan', 'Niroshika 	', '0024', 'Mark correction', 'My mark for Tamil language in this term is 95'),
(15, '1064', ' Ramanathan', 'Niroshika ', 'Admin', 'Phone No correction', 'My correct phone no is 0756798313'),
(16, '1058', 'Shopika', 'Pushpakumar', 'Admin', 'marks is wrong', 'madam,my tamil marks is wrong  it should be 98'),
(17, '1058', 'Shopika', 'Pushpakumar', '0024', 'Attedance problem', 'Madam, i have some medical issues');

-- --------------------------------------------------------

--
-- Table structure for table `division`
--

DROP TABLE IF EXISTS `division`;
CREATE TABLE IF NOT EXISTS `division` (
  `division_id` char(2) NOT NULL,
  `division_name` char(1) DEFAULT NULL,
  PRIMARY KEY (`division_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `division`
--

INSERT INTO `division` (`division_id`, `division_name`) VALUES
('D2', 'B'),
('D1', 'A'),
('D4', 'D'),
('D3', 'C');

-- --------------------------------------------------------

--
-- Table structure for table `extra_activity`
--

DROP TABLE IF EXISTS `extra_activity`;
CREATE TABLE IF NOT EXISTS `extra_activity` (
  `extra_activity_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` char(4) DEFAULT NULL,
  `section` varchar(30) DEFAULT NULL,
  `participation_level` varchar(30) DEFAULT NULL,
  `place` varchar(10) DEFAULT NULL,
  `year` year(4) DEFAULT NULL,
  `type` varchar(30) NOT NULL,
  PRIMARY KEY (`extra_activity_id`),
  KEY `student_id` (`student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `extra_activity`
--

INSERT INTO `extra_activity` (`extra_activity_id`, `student_id`, `section`, `participation_level`, `place`, `year`, `type`) VALUES
(1, '1058', 'Sports', 'District', '2', 2017, 'Volleyball'),
(2, '1054', 'Tamil', 'Zonal', '1', 2017, 'Debate'),
(3, '1064', 'English', 'Provincial', '3', 2018, 'Poem'),
(4, '1083', 'Tamil', 'District', '1', 2018, 'Poem writing'),
(5, '1073', 'Tamil', 'Divisional', '1', 2018, 'Debate'),
(6, '1077', 'English', 'District', '2', 2018, 'Debate'),
(7, '1096', 'English', 'Provincial', '1', 2018, 'Dictation'),
(8, '1031', 'Sports', 'Divisional', NULL, 2018, 'Netball'),
(9, '1034', 'Sports', 'Provincial', '1', 2018, 'Carom'),
(10, '1087', 'English', 'District', '1', 2018, 'Hand writing'),
(11, '1085', 'Tamil', 'District', '2', 2018, 'Singing'),
(12, '1062', 'Tamil', 'Provincial', '3', 2017, 'Dancing'),
(13, '1078', 'English', 'Provincial', '1', 2018, 'Solo acting'),
(14, '1079', 'Sports', 'District', '3', 2018, 'Chess'),
(15, '1087', 'Tamil', 'Divisional', '2', 2018, 'Essay Writing'),
(16, '1084', 'Sports', 'Divisional', NULL, 2018, 'Badminton'),
(17, '1075', 'Tamil', 'Divisional', NULL, 2018, 'Debate'),
(18, '1091', 'Sports', 'Divisional', NULL, 2018, 'Carom'),
(19, '1075', 'English', 'Divisional', NULL, 2018, 'Poem writting'),
(21, '9646', 'Sports', 'Provincial', '1', 2018, 'Chess'),
(22, '9830', 'Tamil', 'District', '1', 2018, 'Poem writting'),
(23, '9854', 'Sports', 'Provincial', '1', 2018, 'Carom'),
(24, '9845', 'English', 'Provincial', '1', 2018, 'Essay Writting'),
(25, '9854', 'Tamil', 'Provincial', '1', 2018, 'Poem Writing'),
(26, '9832', 'English', 'District', '1', 2018, 'Dictation'),
(27, '9819', 'English', 'Divisional', NULL, 2018, 'Essay Writing'),
(28, '9850', 'English', 'District', '3', 2018, 'Poem Writing'),
(29, '9844', 'Tamil', 'District', '1', 2018, 'Singing'),
(30, '9840', 'Tamil', 'Provincial', '1', 2018, 'Poem Writing'),
(31, '9852', 'Sports', 'Provincial', '1', 2018, 'Chess'),
(32, '9824', 'Tamil', 'District', '1', 2018, 'Debate'),
(33, '9814', 'English', 'Divisional', NULL, 2018, 'Singing'),
(34, '9822', 'Tamil', 'Divisional', NULL, 2018, 'Essay Writing'),
(35, '9819', 'Sports', 'Divisional', NULL, 2018, 'Net ball'),
(36, '9861', 'Tamil', 'Provincial', '1', 2018, 'Essay Writing'),
(37, '9873', 'English', 'Divisional', NULL, 2018, 'Essay Writting'),
(39, '9869', 'Tamil', 'Provincial', '3', 2018, 'Poem Writing'),
(40, '9871', 'Sports', 'Divisional', NULL, 2018, 'Chess'),
(41, '1058', 'sports', 'Zonal', '2', 2019, 'netball');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

DROP TABLE IF EXISTS `login`;
CREATE TABLE IF NOT EXISTS `login` (
  `user_name` varchar(30) NOT NULL,
  `password` varchar(50) DEFAULT NULL,
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `status` int(11) NOT NULL DEFAULT '0',
  `user_type` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `user_name` (`user_name`)
) ENGINE=MyISAM AUTO_INCREMENT=12434 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`user_name`, `password`, `user_id`, `status`, `user_type`) VALUES
('8846', '12345', 9011, 1, 'S'),
('8817', '12345', 9012, 1, 'S'),
('8818', '12345', 9013, 1, 'S'),
('8821', '12345', 9014, 1, 'S'),
('8829', '12345', 9015, 1, 'S'),
('8830', '12345', 9016, 1, 'S'),
('8832', '12345', 9017, 1, 'S'),
('8834', '12345', 9018, 1, 'S'),
('8837', '12345', 9019, 1, 'S'),
('8843', '12345', 9020, 1, 'S'),
('8845', '12345', 9021, 1, 'S'),
('8854', '12345', 9022, 1, 'S'),
('8858', '12345', 9023, 1, 'S'),
('8859', '12345', 9024, 1, 'S'),
('8864', '12345', 9025, 1, 'S'),
('8865', '12345', 9026, 1, 'S'),
('8866', '12345', 9027, 1, 'S'),
('8876', '12345', 9028, 1, 'S'),
('8877', '12345', 9029, 1, 'S'),
('8879', '12345', 9030, 1, 'S'),
('8814', '12345', 9031, 1, 'S'),
('8819', '12345', 9032, 1, 'S'),
('8822', '12345', 9033, 1, 'S'),
('8826', '12345', 9034, 1, 'S'),
('8840', '12345', 9035, 1, 'S'),
('8844', '12345', 9036, 1, 'S'),
('8848', '12345', 9037, 1, 'S'),
('8849', '12345', 9038, 1, 'S'),
('8850', '12345', 9039, 1, 'S'),
('8852', '12345', 9040, 1, 'S'),
('8853', '12345', 9041, 1, 'S'),
('8857', '12345', 9042, 1, 'S'),
('8861', '12345', 9043, 1, 'S'),
('8869', '12345', 9044, 1, 'S'),
('8871', '12345', 9045, 1, 'S'),
('8872', '12345', 9046, 1, 'S'),
('8873', '12345', 9047, 1, 'S'),
('8878', '12345', 9048, 1, 'S'),
('8882', '12345', 9049, 1, 'S'),
('8777', '12345', 9050, 1, 'S'),
('0046', '827ccb0eea8a706c4c34a16891f84e7b', 9051, 1, 'A'),
('0075', '827ccb0eea8a706c4c34a16891f84e7b', 9052, 1, 'A'),
('0001', '827ccb0eea8a706c4c34a16891f84e7b', 9053, 1, 'P'),
('0065', '12345', 9081, 1, 'T'),
('0035', '12345', 9080, 1, 'T'),
('0052', '12345', 9079, 1, 'T'),
('0028', '12345', 9078, 1, 'T'),
('0025', '12345', 9077, 1, 'T'),
('0019', '12345', 9076, 1, 'T'),
('0059', '12345', 9075, 1, 'T'),
('0016', '12345', 9074, 1, 'T'),
('0063', '827ccb0eea8a706c4c34a16891f84e7b', 9073, 1, 'T'),
('0030', '12345', 9072, 1, 'T'),
('0070', '12345', 9071, 1, 'T'),
('0062', '12345', 9070, 1, 'T'),
('0039', '12345', 9069, 1, 'T'),
('0024', '827ccb0eea8a706c4c34a16891f84e7b', 9068, 1, 'T'),
('0027', '12345', 9082, 1, 'T'),
('0056', '12345', 9083, 1, 'T'),
('0041', '12345', 9084, 1, 'T'),
('0068', '12345', 9085, 1, 'T'),
('0054', '12345', 9086, 1, 'T'),
('0049', '12345', 9087, 1, 'T'),
('0004', '12345', 9088, 1, 'T'),
('0036', '12345', 9089, 1, 'T'),
('0014', '12345', 9090, 1, 'T'),
('0032', '12345', 9091, 1, 'T'),
('0018', '12345', 9093, 1, 'T'),
('0037', '12345', 9094, 1, 'T'),
('0012', '12345', 9095, 1, 'T'),
('0042', '12345', 9096, 1, 'T'),
('0033', '12345', 9097, 1, 'T'),
('0020', '12345', 9098, 1, 'T'),
('0057', '12345', 9099, 1, 'T'),
('8493', '12345', 9100, 1, 'S'),
('8630', '12345', 9101, 1, 'S'),
('8632', '12345', 9102, 1, 'S'),
('8639', '12345', 9103, 1, 'S'),
('8638', '12345', 9104, 1, 'S'),
('8641', '12345', 9105, 1, 'S'),
('8642', '12345', 9106, 1, 'S'),
('8643', '12345', 9107, 1, 'S'),
('8644', '12345', 9108, 1, 'S'),
('8647', '12345', 9109, 1, 'S'),
('8649', '12345', 9110, 1, 'S'),
('8650', '12345', 9111, 1, 'S'),
('8655', '12345', 9112, 1, 'S'),
('8657', '12345', 9113, 1, 'S'),
('8661', '12345', 9114, 1, 'S'),
('8662', '12345', 9115, 1, 'S'),
('8678', '12345', 9116, 1, 'S'),
('8679', '12345', 9117, 1, 'S'),
('8685', '12345', 9118, 1, 'S'),
('8687', '12345', 9119, 1, 'S'),
('8672', '12345', 9120, 1, 'S'),
('8689', '12345', 9121, 1, 'S'),
('8684', '12345', 9122, 1, 'S'),
('8675', '12345', 9123, 1, 'S'),
('8629', '12345', 9124, 1, 'S'),
('8634', '12345', 9125, 1, 'S'),
('8631', '12345', 9126, 1, 'S'),
('8676', '12345', 9127, 1, 'S'),
('8692', '12345', 9128, 1, 'S'),
('8696', '12345', 9129, 1, 'S'),
('8694', '12345', 9130, 1, 'S'),
('8677', '12345', 9131, 1, 'S'),
('8525', '12345', 9132, 1, 'S'),
('8701', '12345', 9133, 1, 'S'),
('8673', '12345', 9134, 1, 'S'),
('8691', '12345', 9135, 1, 'S'),
('8683', '12345', 9136, 1, 'S'),
('8593', '12345', 9137, 1, 'S'),
('8654', '12345', 9138, 1, 'S'),
('8664', '12345', 9139, 1, 'S'),
('8658', '12345', 9140, 1, 'S'),
('7646', '12345', 9141, 1, 'S'),
('7817', '12345', 9142, 1, 'S'),
('7818', '12345', 9143, 1, 'S'),
('7821', '12345', 9144, 1, 'S'),
('7829', '12345', 9145, 1, 'S'),
('9646', '12345', 9146, 1, 'S'),
('9817', '12345', 9147, 1, 'S'),
('9818', '12345', 9148, 1, 'S'),
('9821', '12345', 9149, 1, 'S'),
('9829', '12345', 9150, 1, 'S'),
('9830', '12345', 9151, 1, 'S'),
('9832', '12345', 9152, 1, 'S'),
('9834', '12345', 9153, 1, 'S'),
('9837', '12345', 12345, 1, 'S'),
('9843', '12345', 12346, 1, 'S'),
('9845', '12345', 12347, 1, 'S'),
('9854', '12345', 12348, 1, 'S'),
('9858', '12345', 12349, 1, 'S'),
('9859', '12345', 12350, 1, 'S'),
('9864', '12345', 12351, 1, 'S'),
('9865', '12345', 12352, 1, 'S'),
('9866', '12345', 12353, 1, 'S'),
('9876', '12345', 12354, 1, 'S'),
('9877', '12345', 12355, 1, 'S'),
('9879', '12345', 12356, 1, 'S'),
('9814', '12345', 12357, 1, 'S'),
('9819', '12345', 12358, 1, 'S'),
('9822', '12345', 12359, 1, 'S'),
('9824', '12345', 12360, 1, 'S'),
('9840', '12345', 12361, 1, 'S'),
('9844', '12345', 12362, 1, 'S'),
('9848', '12345', 12363, 1, 'S'),
('9849', '12345', 12364, 1, 'S'),
('9850', '12345', 12365, 1, 'S'),
('9852', '12345', 12366, 1, 'S'),
('9853', '827ccb0eea8a706c4c34a16891f84e7b', 12367, 1, 'S'),
('9857', '12345', 12368, 1, 'S'),
('9861', '12345', 12369, 1, 'S'),
('9869', '12345', 12370, 1, 'S'),
('9871', '827ccb0eea8a706c4c34a16891f84e7b', 12371, 1, 'S'),
('9872', '12345', 12372, 1, 'S'),
('9873', '12345', 12373, 1, 'S'),
('9878', '12345', 12374, 1, 'S'),
('9882', '12345', 12375, 1, 'S'),
('9777', '12345', 12376, 1, 'S'),
('9496', '12345', 12377, 1, 'S'),
('9630', '12345', 12378, 1, 'S'),
('9632', '12345', 12379, 1, 'S'),
('9639', '12345', 12380, 1, 'S'),
('9638', '12345', 12381, 1, 'S'),
('9641', '12345', 12382, 1, 'S'),
('9642', '12345', 12383, 1, 'S'),
('9643', '12345', 12384, 1, 'S'),
('9644', '12345', 12385, 1, 'S'),
('9647', '12345', 12386, 1, 'S'),
('1058', '827ccb0eea8a706c4c34a16891f84e7b', 12387, 1, 'S'),
('1064', '827ccb0eea8a706c4c34a16891f84e7b', 12388, 1, 'S'),
('1054', '12345', 12389, 1, 'S'),
('1093', '12345', 12390, 1, 'S'),
('1083', '12345', 12391, 1, 'S'),
('1001', '12345', 12392, 1, 'S'),
('1091', '12345', 12393, 1, 'S'),
('1077', '12345', 12394, 1, 'S'),
('1025', '12345', 12395, 1, 'S'),
('1073', '12345', 12396, 1, 'S'),
('1096', '12345', 12397, 1, 'S'),
('1092', '12345', 12398, 1, 'S'),
('1076', '12345', 12399, 1, 'S'),
('1031', '12345', 12400, 1, 'S'),
('1034', '12345', 12401, 1, 'S'),
('1072', '12345', 12402, 1, 'S'),
('1089', '12345', 12403, 1, 'S'),
('1084', '12345', 12404, 1, 'S'),
('1075', '12345', 12405, 1, 'S'),
('1029', '12345', 12406, 1, 'S'),
('1062', '12345', 12407, 1, 'S'),
('1078', '12345', 12408, 1, 'S'),
('1079', '12345', 12409, 1, 'S'),
('1085', '12345', 12410, 1, 'S'),
('1087', '12345', 12411, 1, 'S'),
('1049', '12345', 12412, 1, 'S'),
('1050', '12345', 12413, 1, 'S'),
('1055', '12345', 12414, 1, 'S'),
('1057', '12345', 12415, 1, 'S'),
('1061', '12345', 12416, 1, 'S'),
('1032', '12345', 12417, 1, 'S'),
('1030', '12345', 12418, 1, 'S'),
('1039', '12345', 12419, 1, 'S'),
('1038', '12345', 12420, 1, 'S'),
('1041', '12345', 12421, 1, 'S'),
('1042', '12345', 12422, 1, 'S'),
('1043', '12345', 12423, 1, 'S'),
('1044', '12345', 12424, 1, 'S'),
('1047', '12345', 12425, 1, 'S'),
('1048', '12345', 12426, 1, 'S'),
('1060', '12345', 12427, 1, 'S'),
('1067', '12345', 12428, 1, 'S'),
('1097', '12345', 12429, 1, 'S'),
('1081', '12345', 12430, 1, 'S'),
('9092', '12345', 12431, 0, 'Teacher'),
('1124', 'Aa12345', 12432, 0, 'Student'),
('0100', 'Aa12345', 12433, 1, 'Teacher');

-- --------------------------------------------------------

--
-- Table structure for table `optional_subject`
--

DROP TABLE IF EXISTS `optional_subject`;
CREATE TABLE IF NOT EXISTS `optional_subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` char(4) NOT NULL,
  `basket_1` varchar(30) DEFAULT NULL,
  `basket_2` varchar(30) DEFAULT NULL,
  `basket_3` varchar(30) DEFAULT NULL,
  `aesthetic` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`id`,`student_id`),
  KEY `student_id` (`student_id`),
  KEY `student_id_2` (`student_id`),
  KEY `student_id_3` (`student_id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `optional_subject`
--

INSERT INTO `optional_subject` (`id`, `student_id`, `basket_1`, `basket_2`, `basket_3`, `aesthetic`) VALUES
(4, '1030', 'S10', 'S15', 'S20', NULL),
(5, '1032', 'S11', 'S14', 'S22', NULL),
(6, '1039', 'S12', 'S16', 'S23', NULL),
(7, '1038', 'S11', 'S14', 'S22', NULL),
(8, '1038', 'S11', 'S14', 'S22', NULL),
(9, '1041', 'S12', 'S16', 'S23', NULL),
(10, '1042', 'S10', 'S15', 'S20', NULL),
(11, '1043', 'S10', 'S15', 'S20', NULL),
(12, '1044', 'S11', 'S14', 'S22', NULL),
(13, '1047', 'S11', 'S16', 'S23', NULL),
(14, '1048', 'S12', 'S16', 'S23', NULL),
(15, '1060', 'S11', 'S14', 'S22', NULL),
(16, '1067', 'S10', 'S15', 'S20', NULL),
(17, '1097', 'S10', 'S15', 'S20', NULL),
(18, '1081', 'S10', 'S15', 'S20', NULL),
(19, '1062', 'S11', 'S14', 'S22', NULL),
(20, '1078', 'S16', 'S12', 'S23', NULL),
(21, '1079', 'S11', 'S14', 'S22', NULL),
(22, '1085', 'S11', 'S14', 'S22', NULL),
(23, '1087', 'S10', 'S15', 'S20', NULL),
(24, '1089', 'S10', 'S15', 'S20', NULL),
(25, '1084', 'S12', 'S16', 'S23', NULL),
(26, '1075', 'S12', 'S16', 'S23', NULL),
(27, '1029', 'S11', 'S14', 'S22', NULL),
(28, '1034', 'S11', 'S14', 'S22', NULL),
(29, '1031', 'S10', 'S15', 'S20', NULL),
(30, '1076', 'S10', 'S15', 'S20', NULL),
(31, '1092', 'S11', 'S14', 'S22', NULL),
(32, '1096', 'S11', 'S14', 'S22', NULL),
(33, '1091', 'S10', 'S15', 'S20', NULL),
(34, '1077', 'S10', 'S15', 'S20', NULL),
(35, '1025', 'S12', 'S14', 'S22', NULL),
(36, '1001', 'S12', 'S14', 'S22', NULL),
(37, '1073', 'S12', 'S16', 'S23', NULL),
(38, '1083', 'S12', 'S16', 'S23', NULL),
(39, '1093', 'S11', 'S14', 'S22', NULL),
(40, '1054', 'S11', 'S14', 'S22', NULL),
(41, '1064', 'S12', 'S16', 'S23', NULL),
(42, '1058', 'S10', 'S15', 'S20', NULL),
(43, '1124', 'S10', 'S17', 'S23', ''),
(44, '9818', NULL, NULL, NULL, 'S15'),
(45, '9865', NULL, NULL, NULL, 'S15'),
(46, '9871', NULL, NULL, NULL, 'S14');

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

DROP TABLE IF EXISTS `options`;
CREATE TABLE IF NOT EXISTS `options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_code` varchar(3) NOT NULL,
  `basket` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `suject_code` (`subject_code`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `subject_code`, `basket`) VALUES
(12, 'S16', 'basket_2'),
(11, 'S15', 'basket_2'),
(10, 'S14', 'basket_2'),
(9, 'S12', 'basket_1'),
(8, 'S11', 'basket_1'),
(7, 'S10', 'basket_1'),
(13, 'S19', 'basket_2'),
(14, 'S17', 'basket_2'),
(15, 'S18', 'basket_2'),
(16, 'S20', 'basket_3'),
(17, 'S21', 'basket_3'),
(18, 'S22', 'basket_3'),
(19, 'S23', 'basket_3'),
(20, 'S13', 'basket_2');

-- --------------------------------------------------------

--
-- Table structure for table `principal`
--

DROP TABLE IF EXISTS `principal`;
CREATE TABLE IF NOT EXISTS `principal` (
  `user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `principal_id` char(4) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `phone_no` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`,`principal_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `principal_id` (`principal_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `principal`
--

INSERT INTO `principal` (`user_id`, `id`, `principal_id`, `first_name`, `last_name`, `gender`, `date_of_birth`, `no`, `street`, `city`, `email`, `phone_no`) VALUES
(9053, 1, '0001', 'Bavani', 'Rasaratnam', 'Female', '1959-05-24', 29, 'Lower Street', 'Badulla', 'bawa01@gmail.com', '0765345213');

-- --------------------------------------------------------

--
-- Table structure for table `reset_password`
--

DROP TABLE IF EXISTS `reset_password`;
CREATE TABLE IF NOT EXISTS `reset_password` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `token` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
CREATE TABLE IF NOT EXISTS `student` (
  `user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` char(4) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `class_id` char(3) DEFAULT NULL,
  `division_id` char(2) DEFAULT NULL,
  `phone_no` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`,`student_id`),
  UNIQUE KEY `student_id` (`student_id`),
  UNIQUE KEY `user_id` (`user_id`),
  KEY `class_id` (`class_id`),
  KEY `division_id` (`division_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9889 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`user_id`, `id`, `student_id`, `first_name`, `last_name`, `gender`, `email`, `date_of_birth`, `no`, `street`, `city`, `class_id`, `division_id`, `phone_no`) VALUES
(6045, 126, '8865', 'Chandrakumar', 'Rushanthani', 'Female', 'rusha645@gmail.com', '2007-12-28', 29, 'Othampe Division', 'Badulla', 'C1', 'D2', '0715243822'),
(6044, 125, '8864', 'Thangathurai', 'Abeetha', 'Female', 'abee644@gmail.com', '2007-07-19', 1, 'Othambe Division', 'Badulla', 'C1', 'D2', '0726480239'),
(6043, 124, '8859', 'Ilangeswaran', 'Shashvini', 'Female', 'shashvi643@gmail.com', '2007-11-23', 1, 'Udayatharma Road', 'Badulla', 'C1', 'D2', '0712223292'),
(6042, 123, '8858', 'Mahalingam', 'Harini', 'Female', 'harini642@gmail.com', '2007-03-04', 43, 'Morethota Road', 'Badulla', 'C1', 'D2', '0724007389'),
(6041, 122, '8854', 'Balachandran', 'Lithukshida', 'Female', 'lithu641@gmail.com', '2007-02-26', 2, 'Passara Road', 'Badulla', 'C1', 'D2', '0766588350'),
(6040, 121, '8845', 'Thusharan', 'Sulakshana', 'Female', 'sulaks640@gmail.com', '2007-10-07', 20, 'Elathaluwa Road', 'Badulla', 'C1', 'D2', '0773092323'),
(6010, 120, '8834', 'Ganasekaran ', 'Lakshika', 'Female', 'lakshi610@gmail.com', '2007-09-30', 47, 'Badullupitiya Road', 'Badulla', 'C1', 'D1', '0770723398'),
(6009, 119, '8832', 'Mohamed', 'Asma', 'Female', 'asma609@gmail.com', '2007-02-09', 50, 'Pahalagama Road', 'Badulla', 'C1', 'D1', '0778825890'),
(6008, 118, '8843', 'Shanmugaraja', 'Suwarnameha', 'Female', 'suwarna609@gmail.com', '2007-09-03', 223, 'Bogamadutha Road', 'Badulla', 'C1', 'D1', '0779080799'),
(6007, 117, '8837', 'Nawaratnam', 'Shadharsharani', 'Female', 'shatha607@gmail.com', '2007-05-29', 108, 'Passara Road', 'Badulla', 'C1', 'D1', '0776944170'),
(6006, 116, '8830', 'Mohideen ', 'Akeela', 'Female', 'akee606@gmail.com', '2007-04-14', 162, 'Lower Street', 'Badulla', 'C1', 'D1', '0776265425'),
(6005, 115, '8829', 'Ganasekaran', 'Kavishalini', 'Female', 'kavish605@gmail.com', '2007-11-19', 277, 'Passara Road', 'Badulla', 'C1', 'D1', '0555658748'),
(6004, 114, '8821', 'Paulvarun', 'Oshanara', 'Female', 'osha604@gmail.com', '2007-04-23', 53, 'Galkantha Road', 'Badulla', 'C1', 'D1', '0552224330'),
(6003, 113, '8818', 'Rajathurai', 'Kavisha', 'Female', 'kavi603@gmail.com', '2007-09-08', 23, 'Rockatenna Road', 'Badulla', 'C1', 'D1', '0776761933'),
(6002, 112, '8817', 'Yogaraja', 'Havishna', 'Female', 'havi602@gmail.com', '2007-03-04', 61, 'Badulupitiya Road', 'Badulla', 'C1', 'D1', '0728648354'),
(6001, 111, '8646', 'Nagaraja', 'Bawatharshini', 'Female', 'bawa601@gmail.com', '2007-07-03', 48, 'Mathapatha Road', 'Badulla', 'C1', 'D1', '0774057659'),
(6046, 127, '8866', 'Mohamad', 'Amna', 'Female', 'amna646@gmail.com', '2007-11-21', 43, 'Badulupitiya Road', 'Badulla', 'C1', 'D2', '0724934718'),
(6047, 128, '8876', 'Jeyaratnam', 'Ashvini', 'Female', 'ashvini647@gmail.com', '2007-12-23', 43, 'wewassagama Road', 'Badulla', 'C1', 'D2', '0765344477'),
(6049, 129, '8877', 'Devaratnam', 'Piriyanga', 'Female', 'piriya649@gmail.com', '2007-11-08', 45, 'Passara Road', 'Badulla', 'C1', 'D2', '0779363003'),
(6050, 130, '8879', 'Ganakumar', 'Maduwanthi', 'Female', 'madu650@gmail.com', '2007-05-26', 139, 'Elathuwala Road', 'Badulla', 'C1', 'D2', '0776314216'),
(6080, 131, '8814', 'Thiruchelvan', 'Mirunshicha', 'Female', 'miru680@gmail.com', '2007-03-06', 101, 'Aselapura', 'Badulla', 'C1', 'D3', '0716672627'),
(6081, 132, '8819', 'Rakeep', 'Rashidha', 'Female', 'rashi681@gmail.com', '2007-12-08', 162, 'Lower Street', 'Badulla', 'C1', 'D3', '0771887272'),
(6083, 133, '8822', 'Vijayakumar', 'Yoshini', 'Female', 'yoshi683@gmail.com', '2007-06-04', 28, 'Lower King Street', 'Badulla', 'C1', 'D3', '0774336254'),
(6084, 134, '8824', 'Devaraj ', 'Dhamajanthi', 'Female', 'dhamaya684@gmail.com', '2007-08-31', 58, 'Nepiyar Road', 'Badulla', 'C1', 'D3', '0725257273'),
(6085, 135, '8840', 'Sababathy', 'Raveeshani', 'Female', 'raveesha685@gmail.com', '2007-02-11', 77, 'Hunukottuwa Road', 'Badulla', 'C1', 'D3', '0779865669'),
(6086, 136, '8844', 'Loganathan', 'Haruni', 'Female', 'haruni6086@gmail.com', '2007-10-07', 15, 'Coop Road', 'Badulla', 'C1', 'D3', '0777688762'),
(6087, 137, '8848', 'Chandrakumar', 'Pirithika', 'Female', 'pirthi6087@gmail.com', '2007-10-12', 13, 'Elathaluwa Road', 'Badulla', 'C1', 'D3', '0785445120'),
(6088, 138, '8849', 'Kalaivanan', 'Samithasarani', 'Female', 'samith6088@gmail.com', '2007-12-17', 34, 'Passara Road', 'Badulla', 'C1', 'D3', '0779942684'),
(6089, 139, '8850', 'Jeyaraj', 'Branavika', 'Female', 'branavi6089@gmail.com', '2007-11-15', 23, 'Kajugawatha Road', 'Badulla', 'C1', 'D3', '0728821443'),
(6090, 140, '8852', 'Srikanthan', 'Yuwasri', 'Female', 'yuwa6090@gmail.com', '2007-09-20', 19, 'Rithipana Road', 'Badulla', 'C1', 'D3', '0723299027'),
(6120, 141, '8853', 'Amirtharaj', 'Ladhurshana', 'Female', 'lathu6120@gmail.com', '2007-09-30', 219, 'Spiringvely Road', 'Badulla', 'C1', 'D4', '0719483876'),
(6121, 142, '8857', 'Ganeshan', 'Ushadharshini', 'Female', 'usha6121@gmail.com', '2007-05-05', 47, 'Badulupitiya Road', 'Badulla', 'C1', 'D4', '0771987768'),
(6122, 143, '8861', 'Prabakaran', 'Swetha', 'Female', 'suwe61222gmail.com', '2007-10-23', 31, 'Nothiswataha Road', 'Badulla', 'C1', 'D4', '0716796729'),
(6123, 144, '8869', 'Mahiran', 'Nusha', 'Female', 'nusha6123@gmail.com', '2007-09-12', 181, 'Badullupitiya Road', 'Badulla', 'C1', 'D4', '0772334556'),
(6124, 145, '8871', 'Pugalendran', 'Sanjeewani', 'Female', 'sanjee6124@gmail.com', '2007-09-08', 56, 'Malangmuwa Road', 'Badulla', 'C1', 'D4', '0772795510'),
(6125, 146, '8872', 'Rajathurai', 'Yuganthini', 'Female', 'yuga6125@gmail.com', '2007-03-06', 34, 'Upper Division', 'Badulla', 'C1', 'D4', '0722801737'),
(6126, 147, '8873', 'Jesurajan', 'Jenifer', 'Female', 'jeni6125@gmail.com', '2007-10-27', 243, 'Wewassa Road', 'Badulla', 'C1', 'D4', '0775450235'),
(6127, 148, '8878', 'Imamdeen', 'Shahana', 'Female', 'shaha6127@gmail.com', '2007-05-04', 39, 'Badullupitiya Road', 'Badulla', 'C1', 'D4', '0552223792'),
(6128, 149, '8882', 'Aneesh', 'Rifana', 'Female', 'rifa6128@gmail.com', '2007-12-25', 6, 'Alyawatha Road', 'Badulla', 'C1', 'D4', '0776605230'),
(6129, 150, '8777', 'Nadaraja', 'Harishalini', 'Female', 'hari6129@gmail.com', '2007-07-18', 155, 'Elathaluwa Road', 'Badulla', 'C1', 'D4', '0725987516'),
(7001, 151, '8893', 'Letchumanan', 'Srikanthini', 'Female', 'sri7001@gmail.com', '2006-07-02', 15, 'Cullen Estate', 'Badulla', 'C2', 'D1', '0779121833'),
(7002, 152, '8630', 'Faikar', 'Hamsa', 'Female', 'hams7002@gmail.com', '2006-09-03', 7, 'Badulupittiya Road', 'Badulla', 'C2', 'D1', '0555721494'),
(7003, 153, '8632', 'Rajeswaran ', 'Kirushanija', 'Femlale', 'kirusha7003@gmail.com', '2006-03-04', 190, 'Mahiyangana Road', 'Badulla', 'C2', 'D1', '0722505700'),
(7004, 154, '8639', 'Ananthakumar', 'Amacha', 'Female', 'ama7004@gmail.com', '2006-09-05', 7, 'Uduwara Road', 'Badulla', 'C2', 'D1', '0714412257'),
(7005, 155, '8638', 'Yogendran', 'Sajeetha', 'Female', 'sajee7005@gmail.com', '2006-05-06', 158, 'AmunuwelaPitiya Road', 'Badulla', 'C2', 'D1', '0779961722'),
(7006, 156, '8641', 'Navaratnam', 'Yashini', 'Female', 'yashi7006@gmail.com', '2006-12-23', 7, 'Rithipana Road', 'Badulla', 'C2', 'D1', '0774240750'),
(7007, 157, '8642', 'Jarin', 'Fathima', 'Female', 'fathi7007@gmail.com', '2006-06-07', 23, 'Srinimaladharma', 'Badulla', 'C2', 'D1', '0775774889'),
(7008, 158, '8643', 'Ganajothi', 'Dilasha', 'Female', 'dila7008@gmail.com', '2006-04-12', 12, 'Telbedde Division', 'Badulla', 'C2', 'D2', '0724327080'),
(7009, 159, '8644', 'Kirushnakumar', 'Lukshika', 'Female', 'lukshi7009@gmail.com', '2006-06-26', 45, 'Kottagoda Street', 'Badulla', 'C2', 'D1', '0775737478'),
(7010, 160, '8647', 'Shivashanmugaraja', 'Dhanusiya', 'Female', 'dhanusi7010@gmail.com', '2006-01-15', 17, 'WatwerTank Road', 'Badulla', 'C2', 'D1', '0711128189'),
(7040, 161, '8649', 'Ravi', 'Vidyashini', 'Female', 'vidya7040@gmail.com', '2006-04-03', 232, 'Puwakgodumulla', 'Badulla', 'C2', 'D2', '0786578934'),
(7041, 162, '8650', 'Chandrakumar', 'Vidyalini', 'Female', 'vidya7041@gmail.com', '2006-08-07', 20, 'Jananalamawaththa Road', 'Badulla', 'C2', 'D2', '0786578234'),
(7042, 163, '8655', 'Nazir', 'Shahida', 'Femlale', 'shahi7042@gmail.com', '2006-01-15', 1, 'Badulupitiya Road', 'Badulla', 'C2', 'D2', '0776896534'),
(7043, 164, '8657', 'Fathima', 'Rushdha', 'Female', 'rush7043@gmail.com', '2006-09-02', 190, 'Badulupitiya Road', 'Badulla', 'C2', 'D2', '0776578903'),
(7044, 165, '8661', 'Sivanathan ', 'Piremila', 'Female', 'piremi7044@gmail.com', '2006-01-23', 23, 'Lower Division', 'Badulla', 'C2', 'D2', '0775643214'),
(7080, 166, '8662', 'Thiyagaraja', 'Sarniya', 'Female', 'sarni7080@gmail.com', '2006-01-04', 78, 'Uvakettawala', 'Badulla', 'C2', 'D3', '0776789435'),
(7081, 167, '8678', 'Paveena', 'Nitharshini', 'Female', 'nitharshi7081@gmail.com', '2006-08-09', 56, 'Kalkanda Lower', 'Badulla', 'C2', 'D3', '0765423145'),
(7082, 168, '8679', 'Ravichandran', 'Madushalini', 'Femlale', 'madu7082@gmail.com', '2006-03-09', 21, 'Kovil Road', 'Badulla', 'C2', 'D3', '0556789231'),
(7083, 169, '8685', 'Chandrasegar', 'Kishanthi', 'Female', 'kisha70832gmail.com', '2006-05-03', 12, 'Gangaboda Road', 'Badulla', 'C2', 'D3', '0776785345'),
(7084, 170, '8687', 'Ravichandran', 'Hiroshini', 'Female', 'hiroshi7084@gmail.com', '2006-03-07', 23, 'Deyannawela', 'Badulla', 'C2', 'D3', '0762345216'),
(7140, 171, '8672', 'Kamaladasan', 'Kavishnavi', 'Female', 'kavi7140@gmail.com', '2006-12-12', 78, 'Gangaboda Road', 'Badulla', 'C2', 'D4', '0768954312'),
(7141, 172, '8689', 'Radha', 'Jasmitha', 'Female', 'jasmi7141@gmail.com', '2006-02-21', 89, 'Passara Road', 'Badulla', 'C2', 'D4', '0723451256'),
(7142, 173, '8684', 'Udajaraja', 'Danushini', 'Femlale', 'danushi7142@gmail.com', '2006-01-23', 63, 'RubberWatha Road', 'Badulla', 'C2', 'D4', '0768943214'),
(7143, 174, '8675', 'Ravichandran', 'Divilashini', 'Female', 'divil7143@gmail.com', '2006-03-20', 56, 'Deyannawella', 'Badulla', 'C2', 'D4', '0763245678'),
(7144, 175, '8629', 'Ashokan', 'Aadhitya', 'Female', 'aadhi7144@gmail.com', '2006-12-31', 23, 'Haliela Road', 'Badulla', 'C2', 'D4', '0776978902'),
(8001, 176, '8634', 'Yogeswaran', 'Nishanthini', 'Female', 'nisha8001@gmail.com', '2005-02-03', 149, 'Deyannawela', 'Badulla', 'C3', 'D1', '0723375652'),
(8002, 177, '8631', 'Sedhuraman', 'Dilini', 'Female', 'dili8002@gmail.com', '2005-03-03', 102, 'Yampanawatha Road', 'badulla', 'C3', 'D1', '0552231261'),
(8003, 178, '8676', 'Jeyachandran', 'Abinaja', 'Femlale', 'abi8003@gmail.com', '2005-03-13', 13, 'Dunhindhawatha Road', 'Badulla', 'C3', 'D1', '0777284758'),
(8004, 179, '8692', 'Yogarajah', 'Sharmila', 'Female', 'sharmi8004@gmail.com', '2005-04-03', 13, 'Sinna Alugolla Road', 'Badulla', 'C3', 'D1', '0776584066'),
(8005, 180, '8696', 'Nazeem', 'Fathima', 'Female', 'fathi8005@gmail.com', '2005-01-21', 68, 'Pelipothgama Road', 'Badulla', 'C3', 'D1', '0777077464'),
(8040, 181, '8691', 'Jabeer', 'Jahasha', 'Female', 'jaha8040@gmail.com', '2005-03-31', 19, 'Badulupitiya Road', 'Badulla', 'C3', 'D2', '0767177372'),
(8041, 182, '8677', 'Rajinikanth', 'Mithushalini', 'Female', 'mithu8041gmail.com', '2005-09-03', 54, 'Vineethagama Road', 'Badulla', 'C3', 'D2', '0778967435'),
(8042, 183, '8525', 'Sureswaran', 'Anojini', 'Female', 'anoji8042@gmail.com', '2005-12-02', 11, 'Bogamadutha Road', 'Badulla', 'C3', 'D2', '0729553421'),
(8043, 184, '8701', 'Sivagnanam', 'Logini', 'Female', 'logi8043@gmail.com', '2005-01-30', 15, 'Telebedde Road', 'Badulla', 'C3', 'D2', '0776701234'),
(8044, 185, '8673', 'Thiyagaraja', 'Sasidarani', 'Female', 'sasi8044@gmail.com', '2005-08-23', 196, 'Haliela Road', 'Badulla', 'C3', 'D2', '0726467520'),
(8080, 186, '8683', 'Vigneswaran', 'Abinaja', 'Female', 'abi8080@gmail.com', '2003-12-07', 54, 'Malangamuwa', 'Badulla', 'C3', 'D3', '0789678902'),
(8081, 187, '8593', 'Selvaraja', 'Pavithira', 'Female', 'pavi8081@gmail.com', '2003-06-25', 294, 'Passara Road', 'Badulla', 'C3', 'D3', '0711127170'),
(8082, 188, '8654', 'Sivagnanam', 'Vasanthamalar', 'Female', 'vasanthi8082@gmail.com', '2005-05-04', 158, 'Amunuwelappitiya Road', 'Badulla', 'C3', 'D3', '0723456782'),
(8083, 189, '8664', 'Ramanathan', 'Niroshini', 'Female', 'niro8083@gmail.com', '2005-08-31', 42, 'Deyannawela Road', 'Badulla', 'C3', 'D3', '0555656701'),
(8084, 190, '8658', 'Pushparaj', 'Sobija', 'Female', 'sobi8084@gmail.com', '2005-08-18', 34, 'Clinic Road', 'Badulla', 'C3', 'D3', '0763246030'),
(8120, 191, '7646', 'Sumanthiran', 'Bawathuja', 'Female', 'bawa8120@gmail.com', '2003-07-23', 42, 'Methapetha Road', 'Badulla', 'C3', 'D4', '0774097856'),
(8121, 192, '7817', 'Yogalingam', 'Harishnavi', 'Female', 'hari8121@gmail.com', '2003-12-05', 67, 'Badullupitiya Road', 'Badulla', 'C3', 'D4', '0765643213'),
(8122, 193, '7818', 'Rajalingam', 'Piriyanka', 'Female', 'piri8122@gmail.com', '2003-12-30', 23, 'Upper Division', 'Badulla', 'C3', 'D4', '0556789043'),
(8123, 194, '7821', 'Ganashelwan', 'Piremika', 'Female', 'piremi8123@gmail.com', '2003-08-23', 56, 'Galkantha Road', 'Badulla', 'C3', 'D4', '0553421345'),
(8124, 195, '7829', 'Puvalachandran', 'varunika', 'Female', 'varu8124@gmail.com', '2003-02-26', 14, 'Lower Street', 'Badulla', 'C3', 'D4', '0776878902'),
(9146, 196, '9646', 'Chandrakumar', 'Yuwasri', 'Female', 'yuwa9001@gmail.com', '2004-09-20', 23, 'Othampe Division', 'Badulla', 'C4', 'D1', '0774567890'),
(9147, 197, '9817', 'Yogaraja', 'Havishnavi', 'Female', 'havi9002@gmail.com', '2004-09-08', 32, 'Badllupitiya Road', 'Badulla', 'C4', 'D1', '0778903456'),
(9148, 198, '9818', 'Rajathurai', 'Amna', 'Female', 'amna9003@gmail.com', '2004-05-26', 19, 'Elathaluwa Road', 'Badulla', 'C4', 'D1', '0776314213'),
(9149, 199, '9821', 'Paul', 'Varuni', 'Female', 'varu9004@gmail.com', '2004-09-08', 23, 'Badllupitiya Road', 'Badulla', 'C4', 'D1', '0756798329'),
(9150, 200, '9829', 'Srikanthan', 'Rathi', 'Female', 'rathi9005@gmail.com', '2004-10-27', 23, 'Passara Road', 'Badulla', 'C4', 'D1', '0773612345'),
(9151, 201, '9830', 'Mohideen', 'Akila', 'Female', 'aki9006@gmail.com', '2004-09-02', 32, 'Bogamadutha Road', 'Badulla', 'C4', 'D1', '0756798398'),
(9152, 202, '9832', 'Mohamed', 'Ashna', 'Female', 'ashma9007@gmail.com', '2004-07-19', 50, 'Pahalaghama Road', 'Badula', 'C4', 'D1', NULL),
(9153, 203, '9834', 'Ganasekaran', 'Lakshitha', 'Female', 'lakshi9008@gmail.com', '2004-05-08', 47, 'Badullupitiya Road', 'Badulla', 'C4', 'D1', NULL),
(12345, 204, '9837', 'Nawaratnam', 'Shavika', 'Female', 'shashvi9009@gmail.com', '2004-09-05', 107, 'Passara Road', 'Badula', 'C4', 'D1', '0766990054'),
(12346, 205, '9843', 'Shanmugham', 'Shuwathika', 'Female', 'Shuwa9010@gmail.com', '2004-06-26', 47, 'Bogamadutha Road', 'Badulla', 'C4', 'D1', '0776281234'),
(12347, 206, '9845', 'Thushanthan', 'Shulakshana', 'Female', 'shulak9040@gmail.com', '2004-10-12', 28, 'Elathaluwa Road', 'Badulla', 'C4', 'D2', '0776543216'),
(12348, 207, '9854', 'Balachandran', 'Sharmini', 'Female', 'sharmi9041@gmail.com', '2004-08-26', 25, 'Passara Road', 'Badulla', 'C4', 'D2', '0786756435'),
(12349, 208, '9858', 'Mahalingham', 'Harunja', 'Female', 'haru9042@gmail.com', '2004-02-07', 46, 'Hinigaragolla Road', 'Badulla', 'C4', 'D2', '0789567890'),
(12350, 209, '9859', 'Ilangeshwaran', 'Lavanja', 'Female', 'lavan9043@gmail.com', '2004-11-23', 17, 'Udayaraja Mawaththa', 'Badulla', 'C4', 'D2', '0782345123'),
(12351, 210, '9864', 'Thangathurai', 'Abishayini', 'Female', 'abi9044@gmail.com', '2004-07-19', 19, 'Othampe Division', 'Badulla', 'C4', 'D2', '0786789045'),
(12352, 211, '9865', 'Thangathurai', 'Abishayini', 'Female', 'abi9045@gmail.com', '2004-07-19', 19, 'Othampe Division', 'Badulla', 'C4', 'D2', '0786789045'),
(12353, 212, '9866', 'Chandralingham', 'Rushika', 'Female', 'rushi9046@gmail.com', '2004-12-28', 209, 'Othambe Division', 'Badulla', 'C4', 'D2', '0756798670'),
(12354, 213, '9876', 'Jeyaratnam', 'Venigha', 'Female', 'veni9047@gmail.com', '2004-11-26', 34, 'Rithipana Road', 'Badulla', 'C4', 'D2', '0786789050'),
(12355, 214, '9877', 'Devan', 'Denciya', 'Female', 'denci9048@gmail.com', '2004-01-04', 49, 'Udayaraja Mawaththa', 'Badulla', 'C4', 'D2', '0756798379'),
(12356, 215, '9879', 'Ganakumar', 'jenathika', 'Female', 'jena9049@gmail.com', '2004-05-24', 134, 'Elathaluwa Road', 'Badulla', 'C4', 'D2', '0765423789'),
(12357, 216, '9814', 'Thiruchelvan', 'Thuvaraka', 'Female', 'thuva9080@gmail.com', '2004-12-23', 46, 'Rithipana Road', 'Badulla', 'C4', 'D3', '0778902134'),
(12358, 217, '9819', 'Rakeep', 'Rashidha', 'Female', 'rashi9081@gmail.com', '2004-10-30', 128, 'Lower Street', 'Badulla', 'C4', 'D3', '0771683737'),
(12359, 218, '9822', 'Vijayakumar', 'Thanushalini', 'Female', 'thanu9082@gmail.com', '2004-06-04', 280, 'Lower King Street', 'Badulla', 'C4', 'D3', '0724007398'),
(12360, 219, '9824', 'Devan', 'Dhamayanthi', 'Female', 'dhamaya9083@gmail.com', '2004-03-21', 34, 'Nepiyar Division', 'Badulla', 'C4', 'D3', '0712345786'),
(12361, 220, '9840', 'Sabavathy', 'Raveeshani', 'Female', 'ravee9084@gmail.com', '2004-02-11', 77, 'Hunukottuwa Road', 'Badulla', 'C4', 'D3', '0765430989'),
(12362, 221, '9844', 'Loganathan', 'Harunavathy', 'Female', 'haru9085@gmail.com', '2004-12-30', 45, 'Coop Road', 'Badulla', 'C4', 'D3', '0774354678'),
(12363, 222, '9848', 'Chandralingam', 'Piruthika', 'Female', 'piru9086@gmail.com', '2004-02-24', 45, 'Elathaluwa Road', 'Badulla', 'C4', 'D3', '077657789'),
(12364, 223, '9849', 'Kalaivanan', 'Samiththa', 'Female', 'sami9087@gmail.com', '2004-09-21', 32, 'Passara Road', 'Badulla', 'C4', 'D3', '0778965423'),
(12365, 224, '9850', 'Jejamohan', 'Byravi', 'Female', 'bayra9088@gmail.com', '2004-03-09', 21, 'Anunuwelapitiya Road', 'Badulla', 'C4', 'D3', '0773456879'),
(12366, 225, '9852', 'Srikanthan', 'Yuwathika', 'Female', 'yuwa9120@gmail.com', '2004-09-23', 19, 'Rithipana Road', 'Badulla', 'C4', 'D4', '0789054312'),
(12367, 226, '9853', 'Amirthalingham', 'Shanuja', 'Female', 'shanu9121@gmail.com', '2004-01-23', 213, 'Spiringvely Road', 'Badulla', 'C4', 'D4', '0756798453'),
(12368, 227, '9857', 'Ganeshalingham', 'Uthajatharani', 'Female', 'uthaja9122@gmail.com', '2004-02-26', 412, 'Badullupitiya Road', 'Badulla', 'C4', 'D4', '0776578943'),
(12369, 228, '9861', 'Pirabakaran', 'Saranya', 'Female', 'saran9123@gmail.com', '2004-09-08', 31, 'Vineeththagama Road', 'Badulla', 'C4', 'D4', '0776789542'),
(12370, 229, '9869', 'Chandrakumar', 'Nushka', 'Female', 'nush9124@gmail.com', '2007-03-16', 154, 'Badullupitiya Road', 'Badulla', 'C4', 'D4', '0789567845'),
(12371, 230, '9871', 'Pugalchelvan', 'Sanjeewani', 'Female', 'sajee9125@gmail.com', '2004-11-25', 45, 'Telbedde Estate', 'Badulla', 'C4', 'D4', '0772795510'),
(12387, 9845, '1058', 'Pushpakumar', 'Sobika', 'Female', 'sobi1001@gmail.com', '2003-01-20', 32, 'Clinic Road', 'Badulla', 'C5', 'D1', '0723292927'),
(12388, 9846, '1064', 'Ramanathan', 'Niroshika', 'Female', 'niri1002@gmail.com', '2003-05-21', 45, 'Deyannawela Road', 'Badulla', 'C5', 'D1', '0756798312'),
(12389, 9847, '1054', 'Sivakumar', 'Vasanthy', 'Femlale', 'vasa1003@gmail.com', '2003-04-06', 128, 'Amunuwelapitiya Road', 'Badulla', 'C5', 'D1', '0765423109'),
(12390, 9848, '1093', 'Selvakumar', 'Pavisha', 'Female', 'pavi1003', '2003-01-09', 234, 'Passara Road', 'Badulla', 'C5', 'D1', '0773456123'),
(12391, 9849, '1083', 'Vigneswaran', 'Sowmiya', 'Female', 'sowmi1005@gmail.com', '2003-03-21', 102, 'Malangamuwa Road', 'Badulla', 'C5', 'D1', '0776708902'),
(12396, 9850, '1073', 'Thivakarathas', 'Vithusha', 'Female', 'vithu1040@gmail.com', '2003-09-23', 123, 'Badulla Road', 'Haliela', 'C5', 'D2', '0724007390'),
(12392, 9851, '1001', 'Sivaganam', 'Tharshika', 'Female', 'tharshi1041@gmail.com', '2003-08-03', 12, 'Telebedde', 'Badulla', 'C5', 'D2', '0756798313'),
(12395, 9852, '1025', 'Sureshthash', 'Anoja', 'Female', 'ano1042@gmail.com', '2003-09-26', 127, 'Bogamadutha Road', 'Badulla', 'C5', 'D2', '0765783190'),
(12394, 9853, '1077', 'Rajanikanthan', 'Mithusha', 'Female', 'mithu1043@gmail.com', '2003-02-21', 105, 'Vineethaghama Road', 'Badulla', 'C5', 'D2', '0774345123'),
(12393, 9854, '1091', 'Habeer', 'Jahaza', 'Female', 'jaha1044@gail.com', '2003-09-05', 293, 'Badullupitiya Road', 'Badulla', 'C5', 'D2', '0776078902'),
(12397, 9855, '1096', 'Nazeen', 'Fathima', 'Female', 'fathi1080@gmail.com', '2003-09-08', 608, 'Pelipothghama Road', 'Badulla', 'C5', 'D3', '0729007389'),
(12398, 9856, '1092', 'Yoghalingham', 'Sharmina', 'Female', 'sharmi1081@gmail.com', '2003-07-21', 45, 'Sinna Alugolla Road', 'Badulla', 'C5', 'D3', '0756798320'),
(12399, 9857, '1076', 'Suntharam', 'Aruna', 'Female', 'aru1082@gmail.com', '2003-02-20', 130, 'Rithipana Road', 'Badulla', 'C5', 'D3', '0765423198'),
(12400, 9858, '1031', 'Senthooran', 'Dilani', 'Female', 'dila1083@gmail.com', '2003-03-20', 120, 'Yampanawatha Road', 'Badulla', 'C5', 'D3', '0774356167'),
(12401, 9859, '1034', 'Yogheswaran', 'Nishanthini', 'Female', 'nisha1084@gmail.com', '2003-10-30', 129, 'Deyannawela Road', 'Badulla', 'C5', 'D3', '0776908902'),
(12406, 9860, '1029', 'Ashokan', 'Aathira', 'Female', 'aathi10120@gmail.com', '2003-04-18', 198, 'Badulla Road', 'Haliela', 'C5', 'D4', '0723189027'),
(12405, 9861, '1075', 'Ravichandran', 'Ashoka', 'Female', 'asho10121@gmail.com', '2003-08-14', 56, 'Deyennawela Road', 'Badulla', 'C5', 'D4', '0756678398'),
(12404, 9862, '1084', 'Udayaraja', 'Danushika', 'Female', 'danu10122@gmail.com', '2003-06-13', 609, 'Rubberwatha', 'Badulla', 'C5', 'D4', '0765503190'),
(12403, 9863, '1089', 'Radhakirushnan', 'Jasmitha', 'Female', 'jasmi1089@gmail.com', '2003-12-24', 122, 'Passara Road', 'Badulla', 'C5', 'D4', '0774886123'),
(12402, 9864, '1072', 'Kamalakanthan', 'Kavishnavi', 'Female', 'kavi10124@gmail.com', '2003-10-03', 124, 'Ganbagoda Road', 'Badulla', 'C5', 'D4', '0776908902'),
(12372, 9865, '9872', 'Ravi', 'Yuganthy', 'Female', 'yuga9126@gmail.com', '2004-09-05', 15, 'Malangamuwa Road', 'Badulla', 'C4', 'D4', '0770749798'),
(12373, 9866, '9873', 'Jesuraja', 'Jeniththa', 'Female', 'jeni9126@gmail.com', '2007-11-21', 123, 'Wewassa State', 'Badulla', 'C4', 'D4', '0714521365'),
(12374, 9867, '9878', 'Iamanuwel', 'Sahana', 'Female', 'saga9128@gmail.com', '2004-09-24', 309, 'Badullupitiya Road', 'Badulla', 'C4', 'D4', '0784007389'),
(12375, 9868, '9882', 'Aneesh', 'Rifasha', 'Female', 'rifa9129@gmail.com', '2004-12-29', 66, 'Alyawatha Road', 'Badulla', 'C4', 'D4', '0756798390'),
(12411, 9869, '1087', 'Ravithashan', 'Hirosha', 'Female', 'hiro1006@gmail.com', '2003-10-21', 125, 'Deyannawela', 'Badulla', 'C5', 'D1', '0712223267'),
(12410, 9870, '1085', 'Chandrakumar', 'Krushnavy', 'Female', 'krush1007@gmail.com', '2003-09-03', 245, 'Telbade Division', 'Badulla', 'C5', 'D1', '0756798321'),
(12409, 9871, '1079', 'Ravichandran', 'Mathusha', 'Female', 'mathu1008@gmail.com', '2003-01-08', 213, 'Kovil Road', 'Badulla', 'C5', 'D1', '0723299087'),
(12408, 9872, '1078', 'Chandrabose', 'Nitharshika', 'Female', 'nitharshi1009@gmail.com', '2003-03-09', 561, 'Kalkanda Lower Street', 'Badulla', 'C5', 'D1', '0756798978'),
(12407, 9873, '1062', 'Thiyagaraja', 'Saranya', 'Female', 'sara1010@gmail.com', '2003-05-02', 321, 'Uvakettawela', 'Hali-Ela', 'C5', 'D1', '0712223267'),
(12430, 9874, '1081', 'Sivakaran', 'Piremika', 'Female', 'piremi1045@gmail.com', '2003-07-12', 25, 'Lower Division', 'Badulla', 'C5', 'D2', '0726480745'),
(12429, 9875, '1097', 'Jafunar', 'Rushdha', 'Female', 'rusha1046@gmail.com', '2003-02-21', 190, 'Badullupitiya Road', 'Badulla', 'C5', 'D2', '0726480745'),
(12428, 9876, '1067', 'Nazir', 'Shahidha', 'Female', 'shahi1047@gmail.com', '2003-05-03', 901, 'Badullupitiya Road', 'Badulla', 'C5', 'D2', '0723295327'),
(12427, 9877, '1060', 'Chandrakanth', 'Vidya', 'Female', 'vidya1048@gmail.com', '2003-12-14', 201, 'Jananalamawatha', 'Badulla', 'C5', 'D2', '0756798367'),
(12426, 9878, '1048', 'Ravikumar', 'Vidyashini', 'Female', 'vidyashi1049@gmail.com', '2003-02-05', 324, 'Puwakgodumulla', 'Badula', 'C5', 'D2', '0724934856'),
(12425, 9879, '1047', 'Sivakumaran', 'Thanishika', 'Female', 'thani1085@gmail.com', '2003-01-08', 234, 'Water Tank Road', 'Badulla', 'C5', 'D3', '0723299865'),
(12424, 9880, '1044', 'Kirushnan', 'Lakshika', 'Female', 'lakshi1086@gmail.com', '2003-01-25', 214, 'kapugasella Road', 'Badulla', 'C5', 'D3', '0712345846'),
(12423, 9881, '1043', 'Ganasothy', 'Dilakshika', 'Female', 'dilakshi1087@gmail.com', '2003-08-06', 201, 'Telbadde Division', 'Badulla', 'C5', 'D3', '0723299856'),
(12422, 9882, '1042', 'Jarin', 'Rizna', 'Female', 'riza1088@gmail.com', '2003-05-03', 237, 'Srimaladharmamawatha', 'Badulla', 'C5', 'D3', '0712223267'),
(12421, 9883, '1041', 'Navakumar', 'Yashika', 'Female', 'yashi1089@gmail.com', '2003-04-23', 75, 'Rithipana Road', 'Badulla', 'C5', 'D3', '072329989'),
(12418, 9884, '1030', 'Hasmir', 'Hafsha', 'Female', 'hafsha10125@gmail.com', '2003-08-30', 75, 'Badullupitiya Road', 'Badulla', 'C5', 'D4', '0778965789'),
(12417, 9885, '1032', 'Rajeswar', 'Vithusia', 'Female', 'vithu10126@gmail.com', '2003-05-09', 179, 'Mahiyangana Road', 'Badulla', 'C5', 'D4', '0789656789'),
(12419, 9886, '1039', 'Anandakumar', 'Meryamacha', 'Female', 'mary10127@gmail.com', '2003-02-08', 267, 'Uduwara Road', 'Badulla', 'C5', 'D4', '0712345123'),
(12420, 9887, '1038', 'Yogaswaran', 'Sajeetha', 'Female', 'sajee10128@gmail.com', '2003-08-16', 168, 'Amunuwelapitiya Road', 'Badulla', 'C5', 'D4', '0715243822'),
(12432, 9888, '1124', 'sayini', 'araloganathan', 'Female', 'bsayini96@gmail.com', '2004-09-05', 23, 'vattapalai', 'mulliyavalai', '', 'D2', '0777123456');

-- --------------------------------------------------------

--
-- Table structure for table `subject`
--

DROP TABLE IF EXISTS `subject`;
CREATE TABLE IF NOT EXISTS `subject` (
  `subject_code` char(3) NOT NULL,
  `subject_name` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`subject_code`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `subject`
--

INSERT INTO `subject` (`subject_code`, `subject_name`) VALUES
('S08', 'English'),
('S07', 'Mathematics'),
('S06', 'Science'),
('S02', 'Religion'),
('S01', 'Tamil languages'),
('S09', 'History'),
('S10', 'Business & Accounting studies'),
('S11', 'Geography'),
('S12', 'Citizenship Educations'),
('S13', 'Second Language Sinhala'),
('S14', 'Music'),
('S15', 'Art'),
('S16', 'Dance'),
('S17', 'Tamil Literature'),
('S18', 'English Literature'),
('S19', 'Drama & Theatre'),
('S20', 'Information Technology'),
('S21', 'Agriculture Sciences'),
('S22', 'Home Sciences & Economics'),
('S23', 'Health & Physical Education');

-- --------------------------------------------------------

--
-- Table structure for table `submission`
--

DROP TABLE IF EXISTS `submission`;
CREATE TABLE IF NOT EXISTS `submission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` char(4) NOT NULL,
  `subject_code` char(3) NOT NULL,
  `name` varchar(30) NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  `location` varchar(50) NOT NULL,
  `date_sub` date DEFAULT NULL,
  `time_sub` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `student_id` (`student_id`),
  KEY `subject_code` (`subject_code`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `submission`
--

INSERT INTO `submission` (`id`, `student_id`, `subject_code`, `name`, `size`, `type`, `location`, `date_sub`, `time_sub`) VALUES
(4, 'S006', 'S01', 'cst16026.pdf', 190663, 'application/pdf', 'uploads/cst16026.pdf', '2019-02-11', '06:06:49'),
(6, '1064', 'S01', '34 success.pdf', 162612, 'application/pdf', 'uploads/34 success.pdf', '2019-02-18', '11:30:25'),
(7, '1058', 'S01', '1058 Answer.pdf', 296085, 'application/pdf', 'uploads/1058 Answer.pdf', '2019-02-20', '18:19:57'),
(8, '1058', 'S08', '1058 Answer.pdf', 296085, 'application/pdf', 'uploads/1058 Answer.pdf', '2019-02-20', '18:20:36'),
(9, '1058', 'S08', '1058 Answer 2.pdf', 296085, 'application/pdf', 'uploads/1058 Answer 2.pdf', '2019-02-20', '18:21:25');

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

DROP TABLE IF EXISTS `teacher`;
CREATE TABLE IF NOT EXISTS `teacher` (
  `user_id` int(11) NOT NULL,
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` char(4) NOT NULL,
  `first_name` varchar(30) DEFAULT NULL,
  `last_name` varchar(30) DEFAULT NULL,
  `gender` varchar(10) DEFAULT NULL,
  `email` varchar(30) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `no` int(11) DEFAULT NULL,
  `street` varchar(30) DEFAULT NULL,
  `city` varchar(30) DEFAULT NULL,
  `subject_code` char(3) DEFAULT NULL,
  `phone_no` char(10) DEFAULT NULL,
  PRIMARY KEY (`id`,`teacher_id`),
  UNIQUE KEY `user_id` (`user_id`),
  UNIQUE KEY `teacher_id` (`teacher_id`),
  KEY `subject_code` (`subject_code`)
) ENGINE=MyISAM AUTO_INCREMENT=34 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `teacher`
--

INSERT INTO `teacher` (`user_id`, `id`, `teacher_id`, `first_name`, `last_name`, `gender`, `email`, `date_of_birth`, `no`, `street`, `city`, `subject_code`, `phone_no`) VALUES
(9068, 1, '0024', 'Mathani', 'Govinthan', 'Female', 'matha024@gmail.com', '1765-09-05', 139, 'Hindagoda Road', 'Badulla', 'S01', '0786451234'),
(9069, 2, '0039', 'Shanthakumar', 'Shobana', 'Female', 'soba039@gmail.com', '1976-12-13', 24, 'Elathaluwa Road', 'Badulla', 'S02', '0765423145'),
(9070, 3, '0062', 'Abeyakon', 'Sunthar', 'Male', 'abeya062@gmail.com', '1986-09-12', 154, 'Lower Street', 'Badulla', 'S03', '0753412789'),
(9071, 4, '0070', 'Rasasundaram', 'Niroshini', 'Female', 'niro070@gmail.com', '1988-06-18', 12, 'Lower King Street', 'Badulla', 'S05', '0786543123'),
(9072, 5, '0030', 'Kanakanayagam', 'Yogeswaran', 'Male', 'yoges030@gmail.com', '1988-07-22', 54, 'Methapatha Road', 'Badulla', 'S04', '0773423165'),
(9075, 6, '0059', 'Chandrakanthan', 'Bavithrayalini', 'Female', 'bavithra059@gmail.com', '1979-02-08', 221, 'Bogamaduth Road', 'Badulla', 'S06', '0721435678'),
(9076, 7, '0019', 'Nagalingam', 'Inthirani', 'Female', 'inthira019@gmail.com', '1954-06-30', 28, 'Badulupittiya Road', 'Badulla', 'S07', '0765434215'),
(9073, 8, '0063', 'Shanmugaraja', 'Sutharshan', 'Male', 'sutha063@gmail.com', '1990-09-23', 108, 'Passara Road', 'Badulla', 'S08', '0765434213'),
(9074, 9, '0016', 'Thamilchelvan', 'Thangasamy', 'Male', 'tamil016@gmail.com', '1991-09-30', 276, 'Passara Road', 'Badulla', 'S09', '0712345213'),
(9077, 10, '0025', 'Arupirathasan', 'Ameeran', 'Male', 'ammeran025@gmail.com', '1989-09-15', 108, 'Aselapura Road', 'Badulla', 'S10', '0754312345'),
(9079, 11, '0052', 'Piremachandran', 'Sharmila', 'Female', 'sharmi052@gmail.com', '1992-09-23', 25, 'Elathupula Road', 'Badulla', 'S11', '0721324534'),
(9080, 12, '0035', 'Shivani', 'Selvajothy', 'Female', 'shivani035@gmail.com', '1991-02-05', 34, 'Kinigaragolla', 'Badulla', 'S12', '0556786734'),
(9081, 13, '0065', 'Selvanajakam', 'Jekatheswary', 'Female', 'jekathes065@gmail.com', '1978-09-05', 257, 'Badulupitiya Road', 'Badulla', 'S13', '0786534215'),
(9082, 14, '0027', 'Yoheswaran', 'Imalka', 'Female', 'imalka027@gmail.com', '1987-12-31', 221, 'Bogamadutha Road', 'Badulla', 'S14', '0768965432'),
(9083, 15, '0056', 'Pusparaja', 'Thilaksha', 'Female', 'thilaks05@gmail.com', '1986-09-04', 67, 'Lower Street', 'Badulla', 'S15', '0714567890'),
(9084, 16, '0041', 'Vickneswaran', 'Jeyanthy', 'Female', 'jeya041@gmail.com', '1969-06-26', 45, 'Elathapola Road', 'Badulla', 'S19', '0751234567'),
(9085, 17, '0068', 'Siripalan', 'Nilathevi', 'Female', 'nila068@gmail.com', '1956-09-07', 12, 'Passara Road', 'Badulla', 'S16', '0723451678'),
(9086, 18, '0054', 'Balakumar', 'Thanuja', 'Female', 'thanu054@gmail.com', '1992-06-05', 178, 'Badulupitiya Road', 'Badulla', 'S17', '077689243'),
(9087, 19, '0049', 'Ramya', 'Morayas', 'Female', 'ramya049@gmail.com', '1976-03-21', 45, 'Galkantha Road', 'Badulla', 'S18', '0754356789'),
(9078, 20, '0028', 'Nakachandran', 'Renukadevi', 'Female', 'renu028@gmail.com', '1965-03-09', 43, 'Kinigaragolla Road', 'Badulla', 'S20', '0785643213'),
(9088, 21, '0004', 'Nithiyananthan', 'Kavija', 'Female', 'kavi004@gmail.com', '1978-04-22', 13, 'Badullupitiya Road', 'Badulla', 'S21', '0785643123'),
(9089, 22, '0036', 'Vinayakamoorthy', 'Manjula', 'Female', 'maju036@gmail.com', '1954-09-21', 201, 'Lower Street', 'Badulla', 'S22', '0765678903'),
(9090, 23, '0014', 'Sanmukalingam', 'Piriyatharshika', 'Female', 'piriya014@gmail.com', '1991-09-30', 10, 'Pahalagama', 'Badulla', 'S23', '0765423190'),
(9091, 24, '0032', 'Suganthan', 'Sumathy', 'Female', 'suma032@gmail.com', '1978-02-12', 109, 'Aselapura', 'Badulla', 'S01', '0772314567'),
(9093, 25, '0018', 'Sugirthamenon', 'Thalayaselvi', 'Female', 'thalaya018@gmail.com', '1967-01-21', 34, 'Elathaluwa Road', 'Badulla', 'S02', '0786756432'),
(9094, 26, '0037', 'Vijithakumar', 'Piramila', 'Female', 'pirami037@gmail.com', '1987-09-08', 32, 'Wewwassagama', 'Badulla', 'S03', '0712345123'),
(9095, 27, '0012', 'Devendran', 'Anushika', 'Female', 'anushi0122gmail.com', '1973-09-12', 20, 'Badulupitiya Road', 'Badulla', 'S12', '0786545678'),
(9096, 28, '0042', 'Ramkumar', 'Niranjani', 'Female', 'niranji042@gmail.com', '1976-01-31', 23, 'Lower Street', 'Badulla', 'S12', '0556789432'),
(9097, 29, '0033', 'Suntharam', 'Sorubarani', 'Femlale', 'soruba033@gmail.com', '1967-02-20', 102, 'Lower Street', 'Badulla', 'S20', '0765430987'),
(9098, 30, '0020', 'Muralitharan', 'Wanaroja', 'Female', 'wana020@gmail.com', '1965-02-01', 287, 'Elathaluwa', 'Badulla', 'S13', '0774356123'),
(9099, 31, '0057', 'Arputhalingam', 'Komalaselvi', 'Female', 'komala057@gmail.com', '1970-01-28', 45, 'Passara Road', 'Badulla', 'S21', '0776578902'),
(12431, 32, '0015', 'sampavi', 'shanthakumar', 'Female', 'sam1@gmail.com', '1996-07-14', 11, 'kovil road', 'kurumankadu', 'S09', '0776016682'),
(12433, 33, '0100', 'aathithya', 'jeya', 'Female', 'aathy@gmail.com', '2000-01-01', 654, 'kannaki lane', 'mulliyavalai', 'S01', '0771234562');

-- --------------------------------------------------------

--
-- Table structure for table `term_mark`
--

DROP TABLE IF EXISTS `term_mark`;
CREATE TABLE IF NOT EXISTS `term_mark` (
  `term_mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` varchar(4) NOT NULL,
  `S01` int(11) DEFAULT NULL,
  `S08` int(11) DEFAULT NULL,
  `S06` int(11) DEFAULT NULL,
  `S07` int(11) DEFAULT NULL,
  `S09` int(11) DEFAULT NULL,
  `S02` int(11) DEFAULT NULL,
  `S10` int(11) DEFAULT NULL,
  `S11` int(11) DEFAULT NULL,
  `S14` int(11) DEFAULT NULL,
  `S17` int(11) DEFAULT NULL,
  `S20` int(11) DEFAULT NULL,
  `S23` int(11) DEFAULT NULL,
  `S13` int(11) DEFAULT NULL,
  `S12` int(11) DEFAULT NULL,
  `S15` int(11) DEFAULT NULL,
  `S16` int(11) DEFAULT NULL,
  `S19` int(11) DEFAULT NULL,
  `S21` int(11) DEFAULT NULL,
  `S22` int(11) DEFAULT NULL,
  `total` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `average` double NOT NULL,
  `class_id` varchar(3) NOT NULL,
  `division_id` varchar(2) NOT NULL,
  `term_no` int(2) DEFAULT NULL,
  PRIMARY KEY (`term_mark_id`),
  KEY `student_id` (`student_id`),
  KEY `class_id` (`class_id`),
  KEY `division_id` (`division_id`)
) ENGINE=MyISAM AUTO_INCREMENT=92 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `term_mark`
--

INSERT INTO `term_mark` (`term_mark_id`, `student_id`, `S01`, `S08`, `S06`, `S07`, `S09`, `S02`, `S10`, `S11`, `S14`, `S17`, `S20`, `S23`, `S13`, `S12`, `S15`, `S16`, `S19`, `S21`, `S22`, `total`, `rank`, `average`, `class_id`, `division_id`, `term_no`) VALUES
(1, '9646', 12, 15, 45, 0, 24, 56, NULL, 50, NULL, NULL, NULL, 10, NULL, NULL, 42, NULL, NULL, NULL, 70, 324, 10, 32.4, 'C4', 'D1', 1),
(2, '9817', 50, 34, 64, 9, 57, 30, NULL, 36, NULL, NULL, NULL, 52, 54, 71, NULL, NULL, NULL, NULL, 95, 595, 9, 49.5, 'C4', 'D1', 1),
(3, '9818', 69, 63, 77, 64, 53, 44, NULL, 55, NULL, NULL, NULL, 44, 17, 79, 46, NULL, NULL, NULL, 85, 696, 4, 58, 'C4', 'D1', 1),
(4, '9821', 71, 80, 91, 81, NULL, 45, NULL, 73, NULL, NULL, NULL, 93, 85, 85, 43, NULL, NULL, NULL, 80, 911, 2, 75.9, 'C4', 'D1', 1),
(5, '9829', 61, 36, 66, 35, 56, 35, NULL, 48, NULL, NULL, NULL, 43, 67, 71, 71, NULL, NULL, NULL, 93, 682, 5, 56.8, 'C4', 'D1', 1),
(6, '9830', 61, 37, 57, 11, NULL, 30, NULL, 40, NULL, NULL, NULL, 53, 80, 74, 37, NULL, NULL, NULL, 70, 617, 8, 51.41, 'C4', 'D1', 1),
(7, '9832', 52, 57, 47, 61, NULL, 31, NULL, 55, NULL, NULL, NULL, 51, 85, 58, 45, NULL, NULL, NULL, 70, 700, 3, 58.3, 'C4', 'D1', 1),
(8, '9834', 75, 83, 89, 100, 92, 62, NULL, 90, NULL, NULL, NULL, 85, 93, 94, 91, NULL, NULL, NULL, 90, 1044, 1, 87, 'C4', 'D1', 1),
(9, '9837', 68, 46, 58, 31, 60, 35, NULL, 49, NULL, NULL, NULL, 48, 54, 82, 16, NULL, NULL, NULL, 80, 627, 6, 52.2, 'C4', 'D1', 1),
(10, '9843', 63, 44, 45, 27, NULL, 27, NULL, 53, NULL, NULL, NULL, 56, 60, 68, 43, NULL, NULL, NULL, 90, 625, 7, 52.08, 'C4', 'D1', 1),
(11, '9845', 84, 92, 78, 70, 69, 56, NULL, 72, NULL, NULL, NULL, 83, 96, 96, 73, NULL, NULL, NULL, 73, 944, 3, 78.06, 'C4', 'D2', 1),
(12, '9854', 37, 24, 42, 50, NULL, 33, NULL, 37, NULL, NULL, NULL, 37, 52, 47, 42, NULL, NULL, NULL, 75, 506, 9, 42.6, 'C4', 'D2', 1),
(13, '9858', 70, 76, 91, 93, 85, 72, NULL, 87, NULL, NULL, NULL, 92, 86, 93, 83, NULL, NULL, NULL, 85, 1013, 2, 84.4, 'C4', 'D2', 1),
(14, '9859', 94, 93, 98, 100, 96, 96, NULL, 91, NULL, NULL, NULL, 96, 97, 97, 94, NULL, NULL, NULL, 90, 1142, 1, 95.1, 'C4', 'D2', 1),
(15, '9864', 65, 49, 69, 43, 62, 20, NULL, 54, NULL, NULL, NULL, 45, 77, 85, 66, NULL, NULL, NULL, 65, 700, 6, 58.3, 'C4', 'D2', 1),
(16, '9865', 67, 47, 64, 37, NULL, 25, NULL, 45, NULL, NULL, NULL, 44, 80, 80, 67, NULL, NULL, NULL, 70, 675, 7, 56.2, 'C4', 'D2', 1),
(17, '9866', 62, 37, 57, 27, NULL, 20, NULL, 46, NULL, NULL, NULL, 32, 61, 78, 61, NULL, NULL, NULL, 70, 614, 8, 51.1, 'C4', 'D2', 1),
(18, '9876', 25, 18, 28, 21, 26, 12, NULL, 30, NULL, NULL, NULL, 32, NULL, 35, 28, NULL, NULL, NULL, 40, 295, 10, 24.58, 'C4', 'D2', 1),
(19, '9877', 73, 73, 86, 73, NULL, 48, NULL, 66, NULL, NULL, NULL, 87, 94, 92, 46, NULL, NULL, NULL, 90, 910, 4, 75.8, 'C4', 'D2', 1),
(20, '9879', 77, 44, 93, 72, 67, 57, NULL, 78, NULL, NULL, NULL, 70, 84, 95, 56, NULL, NULL, NULL, 80, 875, 5, 72.9, 'C4', 'D2', 1),
(21, '9814', 81, 68, 64, 77, 54, 28, NULL, 65, NULL, NULL, NULL, 73, 78, 64, 90, NULL, NULL, NULL, 45, 787, 6, 65.58, 'C4', 'D3', 1),
(22, '9819', 83, 80, 41, 79, NULL, 54, NULL, 83, NULL, NULL, NULL, 86, 99, 82, 80, NULL, NULL, NULL, 66, 923, 4, 76.92, 'C4', 'D3', 1),
(23, '9822', 93, 60, 61, 91, 66, 84, NULL, 90, NULL, NULL, NULL, 94, 90, 87, 90, NULL, NULL, NULL, 60, 966, 3, 80.5, 'C4', 'D3', 1),
(24, '9824', 87, 61, 60, 76, 51, 41, NULL, 61, NULL, NULL, NULL, 86, 28, 60, 50, NULL, NULL, NULL, 36, 697, 8, 58.08, 'C4', 'D3', 1),
(25, '9840', 92, 76, 100, 89, 79, 88, NULL, 87, 94, NULL, NULL, 95, 83, 90, NULL, NULL, NULL, NULL, 88, 1061, 1, 88.42, 'C4', 'D3', 1),
(26, '9844', 87, 72, 45, 90, 58, 43, NULL, 60, 45, NULL, NULL, 65, 77, 68, NULL, NULL, NULL, NULL, 86, 804, 5, 67, 'C4', 'D3', 1),
(27, '9848', 63, 64, 27, 39, 52, 32, NULL, 65, NULL, NULL, NULL, 52, 40, 46, NULL, 21, NULL, NULL, 50, 551, 9, 45.91, 'C4', 'D3', 1),
(28, '9849', 93, 80, 100, 94, NULL, 59, NULL, 88, NULL, NULL, NULL, 87, 92, NULL, NULL, 97, NULL, NULL, 69, 1030, 2, 85.8, 'C4', 'D3', 1),
(29, '9850', 84, 61, 44, 83, 18, 34, NULL, 55, 76, NULL, NULL, 56, 79, 94, NULL, NULL, NULL, NULL, 52, 736, 7, 61.35, 'C4', 'D3', 1),
(30, '9852', 95, 71, 83, 85, 51, 42, NULL, 60, 78, NULL, NULL, 90, 69, 52, NULL, NULL, NULL, NULL, 89, 865, 5, 72.08, 'C4', 'D4', 1),
(31, '9853', 97, 56, 78, 86, 54, 60, NULL, 81, NULL, NULL, NULL, 60, 85, 71, NULL, 89, NULL, NULL, 89, 906, 2, 75.5, 'C4', 'D4', 1),
(32, '9857', 96, 67, 76, 78, 66, 50, NULL, 77, NULL, NULL, NULL, 69, 93, 74, NULL, 78, NULL, NULL, 49, 873, 4, 72.75, 'C4', 'D4', 1),
(33, '9861', 99, 83, 87, 89, 74, 86, NULL, 84, 89, NULL, NULL, 98, 90, 70, NULL, NULL, NULL, NULL, 90, 1039, 1, 86.58, 'C4', 'D4', 1),
(34, '9869', 82, 63, 50, 68, NULL, 58, NULL, 50, NULL, NULL, NULL, 77, 64, 61, 90, NULL, NULL, NULL, 55, 805, 7, 67.08, 'C4', 'D4', 1),
(35, '9871', 92, 69, 64, 89, 58, 58, NULL, 82, 80, NULL, NULL, 87, 70, 68, NULL, NULL, NULL, NULL, 70, 887, 3, 73.91, 'C4', 'D4', 1),
(36, '9872', 87, 60, 80, 69, 46, 43, NULL, 68, 72, NULL, NULL, 60, 66, 62, NULL, NULL, NULL, NULL, 81, 794, 8, 66.14, 'C4', 'D4', 1),
(37, '9873', 74, 56, 58, 18, NULL, 43, NULL, 35, 0, NULL, NULL, 68, 76, 88, NULL, 33, NULL, NULL, 60, 618, 10, 49.83, 'C4', 'D4', 1),
(38, '9872', 87, 60, 80, 69, 46, 43, NULL, 68, 72, NULL, NULL, 60, 66, 62, NULL, NULL, NULL, NULL, 81, 794, 8, 66.14, 'C4', 'D4', 1),
(39, '9873', 74, 56, 58, 27, NULL, 43, NULL, 36, NULL, NULL, NULL, 60, 68, 63, NULL, 88, NULL, NULL, 33, 628, 10, 50.83, 'C4', 'D4', 1),
(40, '9878', 73, 62, 53, 83, NULL, 43, NULL, 81, NULL, NULL, NULL, 82, 83, 86, 85, NULL, NULL, NULL, 55, 854, 6, 71.16, 'C4', 'D4', 1),
(41, '9882', 66, 57, 36, 52, NULL, 42, NULL, 29, 60, NULL, NULL, 65, 90, 79, NULL, NULL, NULL, NULL, 39, 661, 9, 55.08, 'C4', 'D4', 1),
(42, '1058', 81, 53, 49, 57, 45, 52, 26, NULL, NULL, NULL, 45, NULL, NULL, NULL, 52, NULL, NULL, NULL, NULL, 460, 7, 51.11, 'C5', 'D1', 1),
(43, '1064', 82, 48, 41, 36, 44, 44, NULL, NULL, NULL, NULL, NULL, 30, NULL, 59, NULL, 33, NULL, NULL, NULL, 417, 8, 46.33, 'C5', 'D1', 1),
(44, '1054', 77, 47, 37, 52, 41, 43, NULL, 74, 51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 62, 484, 3, 53.78, 'C5', 'D1', 1),
(45, '1093', 77, 38, 25, 34, 35, 39, NULL, 39, 29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 52, 339, 9, 37.67, 'C5', 'D1', 1),
(46, '1083', 84, 61, 33, 43, 42, 36, NULL, NULL, NULL, NULL, NULL, 66, NULL, 56, NULL, 43, NULL, NULL, NULL, 464, 6, 51.56, 'C5', 'D1', 1),
(47, '1062', 76, 52, 32, 45, 45, 61, NULL, 80, 60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 80, 471, 5, 59.1, 'C5', 'D1', 1),
(48, '1078', 77, 51, 53, 62, NULL, 53, NULL, NULL, NULL, NULL, NULL, 62, NULL, 60, NULL, 33, NULL, NULL, NULL, 473, 4, 59.1, 'C5', 'D1', 1),
(49, '1079', 88, 61, 63, 50, 33, 65, NULL, 67, 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 55, 552, 2, 61.3, 'C5', 'D1', 1),
(50, '1085', 55, 28, 24, 26, 21, 30, NULL, 49, 21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 40, 294, 10, 33.6, 'C5', 'D1', 1),
(51, '1087', 70, 59, 77, 57, 63, 65, 77, NULL, NULL, NULL, 73, NULL, NULL, NULL, 63, NULL, NULL, NULL, NULL, 604, 1, 67, 'C5', 'D1', 1),
(52, '1073', 85, 42, 37, 43, 36, 44, NULL, NULL, NULL, NULL, NULL, 61, NULL, 37, NULL, 59, NULL, NULL, NULL, 444, 49, 5, 'C5', 'D2', 1),
(53, '1001', 75, 49, 40, 34, 36, 43, NULL, 41, 64, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 37, 419, 6, 46.56, 'C5', 'D2', 1),
(54, '1025', 50, 13, 18, 33, 25, 33, NULL, 8, 49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 27, 256, 10, 28.44, 'C5', 'D2', 1),
(55, '1077', 72, 47, 26, 37, 29, 41, 28, NULL, NULL, NULL, 65, NULL, NULL, NULL, 61, NULL, NULL, NULL, NULL, 406, 7, 45.11, 'C5', 'D2', 1),
(56, '1091', 84, 75, 85, 87, 71, 66, 82, NULL, NULL, NULL, 82, NULL, NULL, NULL, 87, NULL, NULL, NULL, NULL, 719, 1, 79.89, 'C5', 'D2', 1),
(57, '1081', 56, 51, 29, 41, 50, 46, 70, NULL, NULL, NULL, 72, NULL, NULL, NULL, 64, NULL, NULL, NULL, NULL, 479, 4, 53.2, 'C5', 'D2', 1),
(58, '1097', 79, 62, 80, 49, NULL, 72, 67, NULL, NULL, NULL, 81, NULL, NULL, NULL, 77, NULL, NULL, NULL, NULL, 642, 2, 71.3, 'C5', 'D2', 1),
(59, '1067', 68, 29, 30, 24, NULL, 38, 74, NULL, NULL, NULL, 81, NULL, NULL, NULL, 61, NULL, NULL, NULL, NULL, 405, 8, 45, 'C5', 'D2', 1),
(60, '1060', 79, 61, 76, 64, 52, 55, NULL, 74, 66, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 60, 587, 3, 65.2, 'C5', 'D2', 1),
(61, '1048', 22, 64, 28, 23, 45, 34, NULL, NULL, NULL, NULL, NULL, 34, NULL, 21, NULL, 36, NULL, NULL, NULL, 267, 9, 30.12, 'C5', 'D2', 1),
(62, '1096', 82, 74, 85, 75, NULL, 78, NULL, 66, 59, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 87, 719, 1, 79.89, 'C5', 'D3', 1),
(63, '1092', 91, 72, 83, 72, 54, 62, NULL, 76, 75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 77, 662, 2, 73.56, 'C5', 'D3', 1),
(64, '1076', 86, 70, 67, 77, 56, 61, 70, NULL, NULL, NULL, 65, NULL, NULL, NULL, 73, NULL, NULL, NULL, NULL, 625, 3, 69.44, 'C5', 'D3', 1),
(65, '1031', 86, 66, 80, 77, 68, 61, 72, NULL, NULL, NULL, 72, NULL, NULL, NULL, 67, NULL, NULL, NULL, NULL, 619, 4, 67.52, 'C5', 'D3', 1),
(66, '1034', 92, 77, 79, 86, 73, 63, NULL, 83, 72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 67, 604, 5, 66.8, 'C5', 'D3', 1),
(67, '1047', 78, 45, 36, 52, 33, 50, NULL, NULL, NULL, NULL, NULL, 72, NULL, 47, NULL, 59, NULL, NULL, NULL, 472, 9, 52.4, 'C5', 'D3', 1),
(68, '1044', 56, 43, 30, 30, 22, 32, NULL, 22, 42, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 25, 345, 10, 38.3, 'C5', 'D3', 1),
(69, '1043', 95, 63, 92, 82, 49, 68, 66, NULL, NULL, NULL, 66, NULL, NULL, NULL, 65, NULL, NULL, NULL, NULL, 580, 6, 72.5, 'C5', 'D3', 1),
(70, '1042', 62, 48, 43, 44, NULL, 41, 41, NULL, NULL, NULL, 46, NULL, NULL, NULL, 65, NULL, NULL, NULL, NULL, 580, 6, 72.5, 'C5', 'D3', 1),
(71, '1041', 80, 65, 74, 77, 52, 68, NULL, NULL, NULL, NULL, NULL, 63, NULL, 63, NULL, 75, NULL, NULL, NULL, 554, 7, 69.8, 'C5', 'D3', 1),
(72, '1030', 45, 46, 19, 56, NULL, 42, 70, NULL, NULL, NULL, 31, NULL, NULL, NULL, 45, NULL, NULL, NULL, NULL, 306, 8, 34, 'C5', 'D4', 1),
(73, '1032', 86, 80, 90, 89, 76, 78, NULL, 71, 76, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 75, 646, 3, 73.1, 'C5', 'D4', 1),
(74, '1039', 91, 76, 82, 77, NULL, 67, NULL, NULL, NULL, NULL, NULL, 79, NULL, 80, NULL, 75, NULL, NULL, NULL, 699, 2, 77.6, 'C5', 'D4', 1),
(75, '1038', 61, 26, 14, 31, 20, 33, NULL, 80, 40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 43, 348, 7, 38.6, 'C5', 'D4', 1),
(76, '1072', 86, 69, 60, 77, 60, 51, 77, NULL, NULL, NULL, 62, NULL, NULL, NULL, 70, NULL, NULL, NULL, NULL, 612, 5, 68, 'C5', 'D4', 1),
(77, '1089', 13, 23, 56, 26, 32, 34, NULL, 32, 21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 12, 300, 9, 32.09, 'C5', 'D4', 1),
(78, '1084', 83, 56, 55, 54, 44, 51, NULL, NULL, NULL, NULL, NULL, 74, NULL, 72, NULL, 70, NULL, NULL, NULL, 558, 6, 65.3, 'C5', 'D4', 1),
(79, '1075', 85, 67, 39, 43, NULL, 83, NULL, NULL, NULL, NULL, NULL, 55, NULL, 54, NULL, 53, NULL, NULL, NULL, 619, 4, 66.7, 'C5', 'D4', 1),
(80, '1029', 87, 64, 66, 69, 70, 60, NULL, 72, 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 65, 699, 1, 74.1, 'C5', 'D4', 1),
(81, '9832', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, 0, 0, 'C4', 'D1', 0),
(82, '1058', 87, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 87, 0, 21.75, 'C5', 'D1', 2),
(83, '1064', 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 90, 0, 22.5, 'C5', 'D1', 2),
(84, '1054', 70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 70, 0, 17.5, 'C5', 'D1', 2),
(85, '1093', 67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 67, 0, 16.75, 'C5', 'D1', 2),
(86, '1083', 98, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 98, 0, 24.5, 'C5', 'D1', 2),
(87, '1087', 68, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 68, 0, 17, 'C5', 'D1', 2),
(88, '1085', 54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 54, 10, 13.5, 'C5', 'D1', 2),
(89, '1079', 68, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 68, 0, 17, 'C5', 'D1', 2),
(90, '1078', 90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 90, 0, 22.5, 'C5', 'D1', 2),
(91, '1062', 92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 92, 0, 23, 'C5', 'D1', 2);

-- --------------------------------------------------------

--
-- Table structure for table `timetable`
--

DROP TABLE IF EXISTS `timetable`;
CREATE TABLE IF NOT EXISTS `timetable` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` char(3) DEFAULT NULL,
  `division_id` char(2) DEFAULT NULL,
  `name` varchar(20) NOT NULL,
  `location` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`),
  KEY `division_id` (`division_id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timetable`
--

INSERT INTO `timetable` (`id`, `class_id`, `division_id`, `name`, `location`) VALUES
(11, 'C05', 'D2', 'cloud.jpg', 'uploads/cloud.jpg'),
(13, 'C5', 'D1', 'Grade 10A.jpg', 'uploads/Grade 10A.jpg'),
(14, 'C5', 'D2', 'Grade 10B.jpg', 'uploads/Grade 10B.jpg'),
(15, 'C5', 'D3', 'Grade 10C.jpg', 'uploads/Grade 10C.jpg'),
(16, 'C5', 'D4', 'Grade 10D.jpg', 'uploads/Grade 10D.jpg'),
(17, 'C4', 'D1', 'Grade 9A.jpg', 'uploads/Grade 9A.jpg'),
(18, 'C4', 'D2', 'Grade 9B.jpg', 'uploads/Grade 9B.jpg'),
(19, 'C4', 'D3', 'Grade 9C.jpg', 'uploads/Grade 9C.jpg'),
(21, 'C4', 'D4', 'Grade 9D.jpg', 'uploads/Grade 9D.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `upload`
--

DROP TABLE IF EXISTS `upload`;
CREATE TABLE IF NOT EXISTS `upload` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` char(4) NOT NULL,
  `class_id` char(3) NOT NULL,
  `division_id` char(2) NOT NULL,
  `subject_code` char(3) NOT NULL,
  `name` varchar(256) NOT NULL,
  `size` int(11) NOT NULL,
  `type` varchar(256) NOT NULL,
  `location` varchar(256) NOT NULL,
  `date_upload` date DEFAULT NULL,
  `time_upload` time DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `class_id` (`class_id`),
  KEY `division_id` (`division_id`),
  KEY `subject_code` (`subject_code`),
  KEY `teacher_id` (`teacher_id`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `upload`
--

INSERT INTO `upload` (`id`, `teacher_id`, `class_id`, `division_id`, `subject_code`, `name`, `size`, `type`, `location`, `date_upload`, `time_upload`) VALUES
(19, '0063', 'C5', 'D1', 'S08', 'English-01.pdf', 296085, 'application/pdf', 'uploads/English-01.pdf', '2019-02-20', '16:59:36'),
(18, '0024', 'C5', 'D1', 'S01', 'Tamil-02.pdf', 296085, 'application/pdf', 'uploads/Tamil-02.pdf', '2019-02-20', '16:53:45'),
(15, '0024', 'C4', 'D2', 'S01', '34.pdf future.pdf', 175919, 'application/pdf', 'uploads/34.pdf future.pdf', '2019-02-18', '11:04:08'),
(16, '0024', 'C5', 'D1', 'S01', '34 Healthy food.pdf', 472832, 'application/pdf', 'uploads/34 Healthy food.pdf', '2019-02-18', '12:02:32'),
(17, '0024', 'C5', 'D1', 'S01', 'Tamil-01.pdf', 296085, 'application/pdf', 'uploads/Tamil-01.pdf', '2019-02-20', '16:51:36'),
(20, '0063', 'C5', 'D1', 'S08', 'English-02.pdf', 296085, 'application/pdf', 'uploads/English-02.pdf', '2019-02-20', '17:01:56');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `ID` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `name` varchar(30) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`ID`, `username`, `password`, `name`, `email`) VALUES
(1, 'kopi', '$2y$10$vaBigFFOCBXUEgqZ7mmMS.sLdmz5JivyJkBNgtwz8iuriHQZn.rqa', 'Kopiga', 'kopi@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
